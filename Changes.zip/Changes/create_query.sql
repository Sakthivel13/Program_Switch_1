-- =============================================================================
-- NIRIX Diagnostic System - Complete Database Schema
-- Schema: app
-- Version: 7.0
-- Last Updated: 2026-02-23
-- =============================================================================

-- Drop schema if exists (for clean installation)
DROP SCHEMA IF EXISTS app CASCADE;
CREATE SCHEMA app;
SET search_path TO app;

-- =============================================================================
-- EXTENSIONS
-- =============================================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================================================
-- CORE TABLES
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Table: roles
-- -----------------------------------------------------------------------------
CREATE TABLE app.roles (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_roles_name UNIQUE (name)
);

-- Insert default roles
INSERT INTO app.roles (name) VALUES 
    ('technician'),
    ('admin'),
    ('super_admin');

-- -----------------------------------------------------------------------------
-- Table: users
-- -----------------------------------------------------------------------------
CREATE TABLE app.users (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    employee_id VARCHAR(64) UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    pin VARCHAR(255) NOT NULL, -- Hashed PIN
    role_id BIGINT NOT NULL REFERENCES app.roles(id),
    theme VARCHAR(16) NOT NULL DEFAULT 'light',
    is_approved BOOLEAN NOT NULL DEFAULT FALSE,
    is_disabled BOOLEAN NOT NULL DEFAULT FALSE,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    failed_attempts INT DEFAULT 0,
    locked_until TIMESTAMP,
    reset_token VARCHAR(64),
    reset_token_expires TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    deleted_at TIMESTAMP,
    
    CONSTRAINT uq_users_email UNIQUE (email),
    CONSTRAINT uq_users_employee_id UNIQUE (employee_id),
    CONSTRAINT chk_users_theme CHECK (theme IN ('light', 'dark'))
);

CREATE INDEX idx_users_role ON app.users(role_id);
CREATE INDEX idx_users_approved ON app.users(is_approved) WHERE is_approved = TRUE;
CREATE INDEX idx_users_disabled ON app.users(is_disabled) WHERE is_disabled = TRUE;
CREATE INDEX idx_users_locked ON app.users(locked_until) WHERE locked_until IS NOT NULL;
CREATE INDEX idx_users_reset_token ON app.users(reset_token) WHERE reset_token IS NOT NULL;
CREATE INDEX idx_users_reset_expires ON app.users(reset_token_expires) WHERE reset_token_expires IS NOT NULL;

-- -----------------------------------------------------------------------------
-- Table: vehicles
-- -----------------------------------------------------------------------------
CREATE TABLE app.vehicles (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    category VARCHAR(64) NOT NULL,
    vin_pattern VARCHAR(32),
    image_filename VARCHAR(255),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    deleted_at TIMESTAMP,
    
    CONSTRAINT uq_vehicles_name UNIQUE (name),
    CONSTRAINT chk_vehicles_vin_pattern CHECK (
        vin_pattern IS NULL OR 
        vin_pattern ~ '^[A-HJ-NPR-Z0-9\*\?\[\]_-]+$'
    )
);

CREATE INDEX idx_vehicles_active ON app.vehicles(is_active) WHERE is_active = TRUE;

-- =============================================================================
-- CONFIGURATION TABLES
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Table: config
-- -----------------------------------------------------------------------------
CREATE TABLE app.config (
    id BIGSERIAL PRIMARY KEY,
    key_name VARCHAR(255) NOT NULL,
    value_text TEXT,
    user_id BIGINT REFERENCES app.users(id) ON DELETE CASCADE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    
    CONSTRAINT uq_config_key UNIQUE (key_name),
    CONSTRAINT uq_user_config UNIQUE (user_id, key_name)
);

CREATE INDEX idx_config_key ON app.config(key_name);

-- -----------------------------------------------------------------------------
-- Table: diagnostic_sections
-- -----------------------------------------------------------------------------
CREATE TABLE app.diagnostic_sections (
    id SERIAL PRIMARY KEY,
    section_code VARCHAR(50) NOT NULL UNIQUE,
    section_name VARCHAR(100) NOT NULL,
    description TEXT,
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default diagnostic sections
INSERT INTO app.diagnostic_sections (section_code, section_name, description) VALUES 
    ('diagnostics', 'Diagnostics', 'ECU diagnostics and parameter monitoring'),
    ('vehicle_health', 'Vehicle Health Report', 'Comprehensive vehicle health assessment');

-- -----------------------------------------------------------------------------
-- Table: diagnostic_folders
-- -----------------------------------------------------------------------------
CREATE TABLE app.diagnostic_folders (
    id SERIAL PRIMARY KEY,
    ecu_code VARCHAR(50) NOT NULL UNIQUE,
    ecu_name VARCHAR(100) NOT NULL,
    description TEXT,
    protocol VARCHAR(20) CHECK (protocol IN ('UDS', 'CAN', 'KWP2000', 'J1939', 'ISO14229', 'OBDII', 'None')),
    emission VARCHAR(50),
    icon VARCHAR(100),
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_diagnostic_folders_ecu_code ON app.diagnostic_folders(ecu_code);

-- -----------------------------------------------------------------------------
-- Table: diagnostic_actions
-- -----------------------------------------------------------------------------
CREATE TABLE app.diagnostic_actions (
    id SERIAL PRIMARY KEY,
    folder_id INT NOT NULL REFERENCES app.diagnostic_folders(id) ON DELETE CASCADE,
    parameter_code VARCHAR(100) NOT NULL,
    label VARCHAR(200),
    description TEXT,
    execution_class VARCHAR(20) CHECK (execution_class IN ('SINGLE', 'STREAM', 'FLASH', 'DUAL')),
    icon VARCHAR(100),
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_diagnostic_actions_folder_parameter UNIQUE (folder_id, parameter_code)
);

CREATE INDEX idx_diagnostic_actions_folder ON app.diagnostic_actions(folder_id);

-- =============================================================================
-- VEHICLE-SPECIFIC TABLES
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Table: vehicle_sections
-- -----------------------------------------------------------------------------
CREATE TABLE app.vehicle_sections (
    id SERIAL PRIMARY KEY,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL,
    section_type VARCHAR(50) NOT NULL CHECK (section_type IN ('diagnostics', 'vehicle_health')),
    description TEXT,
    icon TEXT,
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_vehicle_sections_vehicle_slug UNIQUE (vehicle_id, slug)
);

CREATE INDEX idx_vehicle_sections_vehicle ON app.vehicle_sections(vehicle_id);

-- -----------------------------------------------------------------------------
-- Table: vehicle_section_map
-- -----------------------------------------------------------------------------
CREATE TABLE app.vehicle_section_map (
    id SERIAL PRIMARY KEY,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    section_id INT NOT NULL REFERENCES app.vehicle_sections(id) ON DELETE CASCADE,
    auto_run_programs JSONB DEFAULT '[]'::jsonb,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_vehicle_section_map_vehicle_section UNIQUE (vehicle_id, section_id)
);

-- -----------------------------------------------------------------------------
-- Table: vehicle_diagnostic_sections
-- -----------------------------------------------------------------------------
CREATE TABLE app.vehicle_diagnostic_sections (
    id SERIAL PRIMARY KEY,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    section_id INT REFERENCES app.diagnostic_sections(id),
    section_name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL,
    description TEXT,
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_vehicle_diag_sections_vehicle_slug UNIQUE (vehicle_id, slug)
);

CREATE INDEX idx_vehicle_diagnostic_sections_vehicle ON app.vehicle_diagnostic_sections(vehicle_id);

-- -----------------------------------------------------------------------------
-- Table: vehicle_diagnostic_actions
-- -----------------------------------------------------------------------------
CREATE TABLE app.vehicle_diagnostic_actions (
    id SERIAL PRIMARY KEY,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    diagnostic_section_id INT NOT NULL REFERENCES app.vehicle_diagnostic_sections(id) ON DELETE CASCADE,
    folder_id INT REFERENCES app.diagnostic_folders(id),
    ecu_code VARCHAR(50) NOT NULL,
    ecu_name VARCHAR(100) NOT NULL,
    description TEXT,
    protocol VARCHAR(20),
    emission VARCHAR(50),
    auto_run_programs JSONB,
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_vehicle_diag_actions_vehicle_ecu UNIQUE (vehicle_id, ecu_code)
);

CREATE INDEX idx_vehicle_diagnostic_actions_vehicle ON app.vehicle_diagnostic_actions(vehicle_id);
CREATE INDEX idx_vehicle_diagnostic_actions_ecu ON app.vehicle_diagnostic_actions(ecu_code);
CREATE INDEX idx_vehicle_diagnostic_actions_auto_run ON app.vehicle_diagnostic_actions USING gin(auto_run_programs);

-- -----------------------------------------------------------------------------
-- Table: vehicle_health_sections
-- -----------------------------------------------------------------------------
CREATE TABLE app.vehicle_health_sections (
    id SERIAL PRIMARY KEY,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    section_name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL,
    description TEXT,
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_vehicle_health_sections_vehicle_slug UNIQUE (vehicle_id, slug)
);

CREATE INDEX idx_vehicle_health_sections_vehicle ON app.vehicle_health_sections(vehicle_id);

-- -----------------------------------------------------------------------------
-- Table: vehicle_health_folders
-- -----------------------------------------------------------------------------
CREATE TABLE app.vehicle_health_folders (
    id SERIAL PRIMARY KEY,
    section_id INT NOT NULL REFERENCES app.vehicle_health_sections(id) ON DELETE CASCADE,
    folder_code VARCHAR(50) NOT NULL,
    folder_name VARCHAR(100) NOT NULL,
    description TEXT,
    execution_class VARCHAR(20) CHECK (execution_class IN ('SINGLE', 'STREAM', 'FLASH', 'DUAL')),
    icon VARCHAR(100),
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_vehicle_health_folders_section_folder UNIQUE (section_id, folder_code)
);

CREATE INDEX idx_vehicle_health_folders_section ON app.vehicle_health_folders(section_id);

-- -----------------------------------------------------------------------------
-- Table: vehicle_health_actions
-- -----------------------------------------------------------------------------
CREATE TABLE app.vehicle_health_actions (
    id SERIAL PRIMARY KEY,
    folder_id INT NOT NULL REFERENCES app.vehicle_health_folders(id) ON DELETE CASCADE,
    parameter_code VARCHAR(100) NOT NULL,
    label VARCHAR(200),
    execution_class VARCHAR(20) CHECK (execution_class IN ('SINGLE', 'STREAM', 'FLASH', 'DUAL')),
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_vehicle_health_actions_folder_parameter UNIQUE (folder_id, parameter_code)
);

CREATE INDEX idx_vehicle_health_actions_folder ON app.vehicle_health_actions(folder_id);

-- -----------------------------------------------------------------------------
-- Table: vehicle_health_map
-- -----------------------------------------------------------------------------
CREATE TABLE app.vehicle_health_map (
    id SERIAL PRIMARY KEY,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    health_section_id INT NOT NULL REFERENCES app.vehicle_health_sections(id) ON DELETE CASCADE,
    folder_id INT NOT NULL REFERENCES app.vehicle_health_folders(id) ON DELETE CASCADE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_vehicle_health_map_section_folder UNIQUE (health_section_id, folder_id)
);

CREATE INDEX idx_vehicle_health_map_vehicle ON app.vehicle_health_map(vehicle_id);

-- =============================================================================
-- TEST DEFINITION TABLES
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Table: tests
-- -----------------------------------------------------------------------------
CREATE TABLE app.tests (
    id VARCHAR(100) PRIMARY KEY,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    label VARCHAR(200) NOT NULL,
    description TEXT,
    module_name VARCHAR(100) NOT NULL,
    function_name VARCHAR(100) NOT NULL,
    button_name VARCHAR(50) DEFAULT 'Run',
    parameter_page_type VARCHAR(50) NOT NULL CHECK (
        parameter_page_type IN (
            'LIVE_PARAMETER', 'WRITE_DATA_IDENTIFIER', 'INPUT_OUTPUT_CONTROL',
            'ROUTINE_CONTROL', 'DTC', 'ECU_FLASHING', 'IUPR',
            'VEHICLE_HEALTH', 'VEHICLE_HEALTH_IO', 'VEHICLE_HEALTH_PHYSICAL',
            'DEALER_DETAILS'
        )
    ),
    function_role VARCHAR(20) CHECK (function_role IN ('READ', 'CLEAR')),
    section VARCHAR(50) NOT NULL CHECK (section IN ('diagnostics', 'vehicle_health')),
    ecu VARCHAR(100),
    parameter VARCHAR(200) NOT NULL,
    version VARCHAR(20) DEFAULT '1.0',
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_tests_vehicle ON app.tests(vehicle_id);
CREATE INDEX idx_tests_lookup ON app.tests(vehicle_id, section, ecu, parameter);
CREATE INDEX idx_tests_section_parameter ON app.tests(section, parameter);
CREATE INDEX idx_tests_page_type ON app.tests(parameter_page_type);

-- -----------------------------------------------------------------------------
-- Table: test_inputs
-- -----------------------------------------------------------------------------
CREATE TABLE app.test_inputs (
    id SERIAL PRIMARY KEY,
    test_id VARCHAR(100) NOT NULL REFERENCES app.tests(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    label VARCHAR(200),
    input_type VARCHAR(20) NOT NULL CHECK (
        input_type IN ('int', 'float', 'string', 'hex', 'bool', 'enum', 'datetime', 'file')
    ),
    length INT CHECK (length > 0 AND length <= 255),
    min_value NUMERIC,
    max_value NUMERIC,
    enum_values JSONB,
    default_value TEXT,
    format_hint VARCHAR(200),
    is_required BOOLEAN DEFAULT FALSE,
    config_key VARCHAR(100),
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_test_inputs_test_name UNIQUE (test_id, name),
    CONSTRAINT chk_test_inputs_config_key CHECK (config_key ~ '^[a-zA-Z0-9_.-]+$')
);

CREATE INDEX idx_test_inputs_test ON app.test_inputs(test_id);

-- -----------------------------------------------------------------------------
-- Table: test_output_limits
-- -----------------------------------------------------------------------------
CREATE TABLE app.test_output_limits (
    id SERIAL PRIMARY KEY,
    test_id VARCHAR(100) NOT NULL REFERENCES app.tests(id) ON DELETE CASCADE,
    signal VARCHAR(100) NOT NULL,
    lsl NUMERIC,
    usl NUMERIC,
    unit VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_test_output_limits_test_signal UNIQUE (test_id, signal),
    CONSTRAINT chk_test_output_limits_lsl_le_usl CHECK (
        lsl IS NULL OR usl IS NULL OR lsl <= usl
    )
);

CREATE INDEX idx_test_output_limits_test ON app.test_output_limits(test_id);

-- -----------------------------------------------------------------------------
-- Table: test_execution_config
-- -----------------------------------------------------------------------------
CREATE TABLE app.test_execution_config (
    id SERIAL PRIMARY KEY,
    test_id VARCHAR(100) NOT NULL UNIQUE REFERENCES app.tests(id) ON DELETE CASCADE,
    execution_mode VARCHAR(20) NOT NULL CHECK (
        execution_mode IN ('single', 'live', 'stream', 'flash', 'flashing')
    ),
    supports_run_all BOOLEAN DEFAULT TRUE,
    timeout_sec INT DEFAULT 15 CHECK (timeout_sec >= 0 AND timeout_sec <= 3600),
    max_retries INT DEFAULT 3 CHECK (max_retries >= 0 AND max_retries <= 10),
    retry_delay_sec NUMERIC(5,2) DEFAULT 1.5 CHECK (retry_delay_sec >= 0 AND retry_delay_sec <= 10),
    retry_on_timeout BOOLEAN DEFAULT FALSE,
    retry_on_exception BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_test_execution_config_test ON app.test_execution_config(test_id);

-- -----------------------------------------------------------------------------
-- Table: test_flashing_config
-- -----------------------------------------------------------------------------
CREATE TABLE app.test_flashing_config (
    id SERIAL PRIMARY KEY,
    test_id VARCHAR(100) NOT NULL UNIQUE REFERENCES app.tests(id) ON DELETE CASCADE,
    file_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(10) NOT NULL CHECK (file_type IN ('HEX', 'BIN', 'SREC', 'S19', 'SRE')),
    method VARCHAR(20) NOT NULL CHECK (method IN ('UDS', 'BOOTLOADER', 'OEM', 'CAN', 'KWP')),
    required_inputs JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- -----------------------------------------------------------------------------
-- Table: test_definition_versions
-- -----------------------------------------------------------------------------
CREATE TABLE app.test_definition_versions (
    id SERIAL PRIMARY KEY,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    schema_version VARCHAR(20),
    tests_hash VARCHAR(64) NOT NULL,
    source VARCHAR(50) DEFAULT 'filesystem',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    
    CONSTRAINT uq_test_definition_versions_vehicle_hash UNIQUE (vehicle_id, tests_hash)
);

CREATE INDEX idx_test_definition_versions_vehicle ON app.test_definition_versions(vehicle_id);

-- =============================================================================
-- EXECUTION HISTORY TABLES
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Table: test_execution_results
-- -----------------------------------------------------------------------------
CREATE TABLE app.test_execution_results (
    id SERIAL PRIMARY KEY,
    test_id VARCHAR(100) REFERENCES app.tests(id) ON DELETE SET NULL,
    task_id VARCHAR(100) NOT NULL,
    vehicle_id INT REFERENCES app.vehicles(id) ON DELETE SET NULL,
    user_id INT REFERENCES app.users(id) ON DELETE SET NULL,
    pass BOOLEAN,
    exception TEXT,
    output_json JSONB,
    limit_violations JSONB DEFAULT '[]'::jsonb,
    duration_ms INT CHECK (duration_ms >= 0),
    attempts INT DEFAULT 1 CHECK (attempts > 0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) PARTITION BY RANGE (created_at);

CREATE INDEX idx_test_execution_results_test ON app.test_execution_results(test_id);
CREATE INDEX idx_test_execution_results_vehicle ON app.test_execution_results(vehicle_id);
CREATE INDEX idx_test_execution_results_user ON app.test_execution_results(user_id);
CREATE INDEX idx_test_execution_results_created ON app.test_execution_results(created_at);

-- Create initial partitions
CREATE TABLE app.test_execution_results_2026_01 PARTITION OF app.test_execution_results
    FOR VALUES FROM ('2026-01-01') TO ('2026-02-01');
CREATE TABLE app.test_execution_results_2026_02 PARTITION OF app.test_execution_results
    FOR VALUES FROM ('2026-02-01') TO ('2026-03-01');
CREATE TABLE app.test_execution_results_2026_03 PARTITION OF app.test_execution_results
    FOR VALUES FROM ('2026-03-01') TO ('2026-04-01');

-- -----------------------------------------------------------------------------
-- Table: logs
-- -----------------------------------------------------------------------------
CREATE TABLE app.logs (
    id BIGSERIAL PRIMARY KEY,
    filename VARCHAR(255) NOT NULL,
    vehicle_name VARCHAR(255) NOT NULL,
    vin VARCHAR(17),
    vin_source VARCHAR(20),
    auto_run_session_id VARCHAR(100),
    user_id BIGINT NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    vehicle_id BIGINT REFERENCES app.vehicles(id) ON DELETE SET NULL,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    
    CONSTRAINT chk_logs_vin_format CHECK (
        vin IS NULL OR vin ~ '^[A-HJ-NPR-Z0-9]{17}$'
    ),
    CONSTRAINT chk_logs_vin_source CHECK (
        vin_source IS NULL OR vin_source IN ('auto', 'manual', 'none')
    )
);

CREATE INDEX idx_logs_vehicle ON app.logs(vehicle_name);
CREATE INDEX idx_logs_vin ON app.logs(vin);
CREATE INDEX idx_logs_user ON app.logs(user_id);
CREATE INDEX idx_logs_created ON app.logs(created_at);
CREATE INDEX idx_logs_auto_run_session ON app.logs(auto_run_session_id);
CREATE INDEX idx_logs_vehicle_vin_created ON app.logs(vehicle_name, vin, created_at DESC);
CREATE INDEX idx_logs_deleted ON app.logs(is_deleted) WHERE is_deleted = FALSE;

-- =============================================================================
-- AUTO-RUN SESSION TABLES
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Table: auto_run_sessions
-- -----------------------------------------------------------------------------
CREATE TABLE app.auto_run_sessions (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL UNIQUE,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    user_id INT REFERENCES app.users(id) ON DELETE SET NULL,
    user_login_id UUID,
    vehicle_name VARCHAR(255) NOT NULL,
    section_type VARCHAR(30) NOT NULL DEFAULT 'diagnostics' CHECK (section_type IN ('diagnostics', 'vehicle_health')),
    vin VARCHAR(50),
    vin_source VARCHAR(20) DEFAULT 'none' CHECK (vin_source IN ('none', 'auto', 'manual')),
    status VARCHAR(20) NOT NULL DEFAULT 'started' CHECK (status IN ('started', 'running', 'completed', 'stopped', 'failed', 'expired')),
    programs_config JSONB,
    vin_input_needed BOOLEAN DEFAULT FALSE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP,
    last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    cleanup_at TIMESTAMP,
    
    CONSTRAINT chk_auto_run_sessions_vin CHECK (
        vin IS NULL OR vin ~ '^[A-HJ-NPR-Z0-9]{17}$'
    )
);

CREATE INDEX idx_auto_run_sessions_vehicle ON app.auto_run_sessions(vehicle_id);
CREATE INDEX idx_auto_run_sessions_user ON app.auto_run_sessions(user_id);
CREATE INDEX idx_auto_run_sessions_status ON app.auto_run_sessions(status);
CREATE INDEX idx_auto_run_sessions_vin ON app.auto_run_sessions(vin);
CREATE INDEX idx_auto_run_sessions_user_login ON app.auto_run_sessions(user_login_id);
CREATE INDEX idx_auto_run_sessions_cleanup ON app.auto_run_sessions(last_accessed) WHERE status IN ('running', 'started');
CREATE INDEX idx_auto_run_sessions_updated ON app.auto_run_sessions(updated_at);

-- -----------------------------------------------------------------------------
-- Table: auto_run_results
-- -----------------------------------------------------------------------------
CREATE TABLE app.auto_run_results (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL REFERENCES app.auto_run_sessions(session_id) ON DELETE CASCADE,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    user_id INT REFERENCES app.users(id) ON DELETE SET NULL,
    program_id VARCHAR(100) NOT NULL,
    program_name VARCHAR(255),
    program_type VARCHAR(20) NOT NULL DEFAULT 'single' CHECK (program_type IN ('single', 'stream')),
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'success', 'failed', 'manual', 'skipped')),
    passed BOOLEAN,
    result_value TEXT,
    result_data JSONB,
    error_message TEXT,
    manual_input BOOLEAN DEFAULT FALSE,
    log_as_vin BOOLEAN NOT NULL DEFAULT FALSE,
    source TEXT DEFAULT 'section',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_auto_run_results_session_program UNIQUE (session_id, program_id)
);

CREATE INDEX idx_auto_run_results_session ON app.auto_run_results(session_id);
CREATE INDEX idx_auto_run_results_program ON app.auto_run_results(program_id);
CREATE INDEX idx_auto_run_results_source ON app.auto_run_results(source);

-- -----------------------------------------------------------------------------
-- Table: auto_run_stream_values
-- -----------------------------------------------------------------------------
CREATE TABLE app.auto_run_stream_values (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL REFERENCES app.auto_run_sessions(session_id) ON DELETE CASCADE,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    program_id VARCHAR(100) NOT NULL,
    signal_name VARCHAR(100) NOT NULL,
    signal_value NUMERIC,
    signal_unit VARCHAR(20),
    lsl NUMERIC,
    usl NUMERIC,
    is_within_limit BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_auto_run_stream_values_session_signal UNIQUE (session_id, signal_name)
);

CREATE INDEX idx_auto_run_stream_values_session ON app.auto_run_stream_values(session_id);
CREATE INDEX idx_auto_run_stream_values_updated ON app.auto_run_stream_values(updated_at);

-- -----------------------------------------------------------------------------
-- Table: ecu_active_status
-- -----------------------------------------------------------------------------
CREATE TABLE app.ecu_active_status (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL REFERENCES app.auto_run_sessions(session_id) ON DELETE CASCADE,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    ecu_code VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT FALSE,
    last_response TIMESTAMP,
    error_count INT DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_ecu_active_status_session_ecu UNIQUE (session_id, ecu_code)
);

CREATE INDEX idx_ecu_active_status_session ON app.ecu_active_status(session_id);
CREATE INDEX idx_ecu_active_status_ecu ON app.ecu_active_status(ecu_code);
CREATE INDEX idx_ecu_active_status_cleanup ON app.ecu_active_status(updated_at);

-- -----------------------------------------------------------------------------
-- Table: auto_run_vin_log
-- -----------------------------------------------------------------------------
CREATE TABLE app.auto_run_vin_log (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL REFERENCES app.auto_run_sessions(session_id) ON DELETE CASCADE,
    program_id VARCHAR(100) NOT NULL,
    vin VARCHAR(17) NOT NULL,
    source VARCHAR(20) NOT NULL CHECK (source IN ('auto', 'manual')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_auto_run_vin_log_vin CHECK (vin ~ '^[A-HJ-NPR-Z0-9]{17}$')
);

CREATE INDEX idx_auto_run_vin_log_session ON app.auto_run_vin_log(session_id);

-- =============================================================================
-- USER PERMISSION TABLES
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Table: user_vehicle_permissions
-- -----------------------------------------------------------------------------
CREATE TABLE app.user_vehicle_permissions (
    user_id INT NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    vehicle_id INT NOT NULL REFERENCES app.vehicles(id) ON DELETE CASCADE,
    granted_by INT REFERENCES app.users(id) ON DELETE SET NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT now(),
    
    PRIMARY KEY (user_id, vehicle_id)
);

CREATE INDEX idx_uvp_user ON app.user_vehicle_permissions(user_id);
CREATE INDEX idx_uvp_vehicle ON app.user_vehicle_permissions(vehicle_id);

-- -----------------------------------------------------------------------------
-- Table: user_test_permissions
-- -----------------------------------------------------------------------------
CREATE TABLE app.user_test_permissions (
    id SERIAL PRIMARY KEY,
    user_id INT NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    test_action_id VARCHAR(100) NOT NULL,
    permission_type VARCHAR(20) DEFAULT 'execute' CHECK (permission_type IN ('execute', 'view', 'admin')),
    granted_by INT REFERENCES app.users(id) ON DELETE SET NULL,
    is_active BOOLEAN DEFAULT TRUE,
    expires_at TIMESTAMP,
    granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uq_user_test_permissions_user_test_type UNIQUE (user_id, test_action_id, permission_type)
);

CREATE INDEX idx_user_test_permissions_user ON app.user_test_permissions(user_id);
CREATE INDEX idx_user_test_permissions_test ON app.user_test_permissions(test_action_id);

-- -----------------------------------------------------------------------------
-- Table: user_health_permissions
-- -----------------------------------------------------------------------------
CREATE TABLE app.user_health_permissions (
    user_id BIGINT NOT NULL,
    action_id BIGINT NOT NULL,
    PRIMARY KEY (user_id, action_id),
    FOREIGN KEY (user_id) REFERENCES app.users(id) ON DELETE CASCADE
    -- Note: action_id references vehicle_health_actions.id but FK omitted for flexibility
);

-- =============================================================================
-- SYSTEM TABLES
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Table: live_system_track
-- -----------------------------------------------------------------------------
CREATE TABLE app.live_system_track (
    id BIGSERIAL PRIMARY KEY,
    session_id VARCHAR(64) NOT NULL,
    server_base_url VARCHAR(255) NOT NULL,
    user_id BIGINT NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    host_name VARCHAR(128) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    os_name VARCHAR(128) NOT NULL,
    first_seen TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_active_at TIMESTAMP,
    last_seen TIMESTAMP,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    
    CONSTRAINT uq_live_system_session_server UNIQUE (session_id, server_base_url)
);

CREATE INDEX idx_live_system_user ON app.live_system_track(user_id);
CREATE INDEX idx_live_system_active ON app.live_system_track(is_active) WHERE is_active = TRUE;
CREATE INDEX idx_live_system_last_active ON app.live_system_track(last_active_at) WHERE last_active_at IS NOT NULL;

-- -----------------------------------------------------------------------------
-- Table: user_login_sessions
-- -----------------------------------------------------------------------------
CREATE TABLE app.user_login_sessions (
    id SERIAL PRIMARY KEY,
    user_id INT NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    login_id UUID NOT NULL,
    ip_address INET,
    user_agent TEXT,
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    
    CONSTRAINT uq_user_login_sessions_user_login UNIQUE (user_id, login_id)
);

CREATE INDEX idx_user_login_sessions_user ON app.user_login_sessions(user_id);
CREATE INDEX idx_user_login_sessions_active ON app.user_login_sessions(is_active) WHERE is_active = TRUE;

-- -----------------------------------------------------------------------------
-- Table: audit_log
-- -----------------------------------------------------------------------------
CREATE TABLE app.audit_log (
    id BIGSERIAL PRIMARY KEY,
    user_id INT REFERENCES app.users(id) ON DELETE SET NULL,
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id VARCHAR(100),
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_log_user ON app.audit_log(user_id);
CREATE INDEX idx_audit_log_entity ON app.audit_log(entity_type, entity_id);
CREATE INDEX idx_audit_log_created ON app.audit_log(created_at);

-- -----------------------------------------------------------------------------
-- Table: schema_lock
-- -----------------------------------------------------------------------------
CREATE TABLE app.schema_lock (
    version TEXT NOT NULL,
    locked BOOLEAN NOT NULL DEFAULT TRUE,
    locked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Insert initial schema lock
INSERT INTO app.schema_lock (version, locked) VALUES ('7.0', TRUE);

-- =============================================================================
-- FUNCTIONS AND TRIGGERS
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Function: update_updated_at_column()
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION app.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to tables with updated_at
CREATE TRIGGER trigger_update_users_updated_at BEFORE UPDATE ON app.users
    FOR EACH ROW EXECUTE FUNCTION app.update_updated_at_column();

CREATE TRIGGER trigger_update_vehicles_updated_at BEFORE UPDATE ON app.vehicles
    FOR EACH ROW EXECUTE FUNCTION app.update_updated_at_column();

CREATE TRIGGER trigger_update_tests_updated_at BEFORE UPDATE ON app.tests
    FOR EACH ROW EXECUTE FUNCTION app.update_updated_at_column();

CREATE TRIGGER trigger_update_auto_run_sessions_updated_at BEFORE UPDATE ON app.auto_run_sessions
    FOR EACH ROW EXECUTE FUNCTION app.update_updated_at_column();

-- -----------------------------------------------------------------------------
-- Function: cleanup_expired_sessions()
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION app.cleanup_expired_sessions()
RETURNS INT AS $$
DECLARE
    cleaned_count INT;
BEGIN
    -- Mark expired auto-run sessions
    UPDATE app.auto_run_sessions
    SET status = 'expired', 
        ended_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE status IN ('running', 'started')
      AND last_accessed < NOW() - INTERVAL '2 hours'
    RETURNING COUNT(*) INTO cleaned_count;
    
    -- Clean up old stream values
    DELETE FROM app.auto_run_stream_values
    WHERE updated_at < NOW() - INTERVAL '1 hour';
    
    -- Clean up old ECU status
    DELETE FROM app.ecu_active_status
    WHERE updated_at < NOW() - INTERVAL '1 hour';
    
    -- Deactivate stale login sessions
    UPDATE app.user_login_sessions
    SET is_active = FALSE
    WHERE is_active = TRUE
      AND last_activity < NOW() - INTERVAL '24 hours';
    
    RETURN cleaned_count;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- Function: create_next_month_partition()
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION app.create_next_month_partition()
RETURNS void AS $$
DECLARE
    next_month DATE;
    partition_name TEXT;
    start_date TEXT;
    end_date TEXT;
BEGIN
    next_month := date_trunc('month', NOW() + INTERVAL '1 month');
    partition_name := 'test_execution_results_' || to_char(next_month, 'YYYY_MM');
    start_date := to_char(next_month, 'YYYY-MM-DD');
    end_date := to_char(next_month + INTERVAL '1 month', 'YYYY-MM-DD');
    
    EXECUTE format('
        CREATE TABLE IF NOT EXISTS app.%I 
        PARTITION OF app.test_execution_results
        FOR VALUES FROM (%L) TO (%L)
    ', partition_name, start_date, end_date);
END;
$$ LANGUAGE plpgsql;

-- =============================================================================
-- COMMENTS
-- =============================================================================

COMMENT ON TABLE app.auto_run_sessions IS 'Auto-run session tracking';
COMMENT ON COLUMN app.auto_run_sessions.vin IS 'Vehicle Identification Number (17 chars, no I/O/Q)';
COMMENT ON COLUMN app.auto_run_sessions.vin_source IS 'Source of VIN: none, auto, manual';

COMMENT ON TABLE app.auto_run_results IS 'Results of auto-run programs';
COMMENT ON COLUMN app.auto_run_results.result_data IS 'JSON structure varies by program type:
- Single tests: {"value": any}
- Stream tests: {"battery_voltage": number, ...}
- DTC tests: {"dtcs": [{"code": string, "status": string}]}
- ECU status: {"is_active": boolean, "ecu_code": string}';

COMMENT ON TABLE app.vehicle_diagnostic_actions IS 'Vehicle-specific ECU configurations';
COMMENT ON COLUMN app.vehicle_diagnostic_actions.auto_run_programs IS 'Array of auto-run program objects with structure:
{
  "program_id": string,
  "program_name": string,
  "program_type": "single"|"stream",
  "module_name": string,
  "function_name": string,
  "execution_mode": "single"|"stream"|"flashing",
  "display_type": "text"|"value"|"status"|"json",
  "display_label": string,
  "display_unit": string|null,
  "display_pages": ["section","ecu","parameter"],
  "ecu_targets": string[],
  "output_limits": [{"signal": string, "lsl": number, "usl": number, "unit": string}],
  "fallback_action": "none"|"manual_input"|"warn_and_continue"|"block",
  "log_as_vin": boolean,
  "is_required": boolean,
  "timeout_sec": number,
  "sort_order": integer
}';

-- =============================================================================
-- GRANTS (adjust as needed for your security model)
-- =============================================================================
GRANT ALL ON SCHEMA app TO nirix_app;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA app TO nirix_app;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA app TO nirix_app;