vin_read.py,

# -*- coding: utf-8 -*-
"""
Auto-run: VIN Read (UDS DID F190)

program_id: AUTO_VIN_READ
module_name: vin_read
function_name: read_vin

Returns: {"vin": "<VIN>", "raw": {...}}
Raises RuntimeError on failure so UI can fallback to manual VIN input.

Version: 2.1.0
Last Updated: 2026-02-23

FIXES:
- PROTO-001: Fixed flow control destination (send to ECU_RESPONSE_ID not TESTER_ID)
- PROTO-002: Fixed timeout reset in ISO-TP
- PROTO-003: Added retry for flow control
- PROTO-006: Added 29-bit CAN ID support
- PROTO-005: Added bus state validation
- CAN-001: Added bus validation before operations
"""

from __future__ import annotations

import time
import logging
from typing import Dict, Any, Optional, List, Tuple

import can

# =============================================================================
# CONSTANTS
# =============================================================================

DEFAULT_TESTER_ID = 0x7F0
DEFAULT_ECU_RESPONSE_ID = 0x7F1
DEFAULT_TIMEOUT = 5.0
DEFAULT_RETRY_COUNT = 3
FLOW_CONTROL_RETRY_COUNT = 3
FLOW_CONTROL_TIMEOUT = 1.0

# ISO-TP protocol constants
ISO_TP_SINGLE_FRAME = 0x0
ISO_TP_FIRST_FRAME = 0x1
ISO_TP_CONSECUTIVE_FRAME = 0x2
ISO_TP_FLOW_CONTROL = 0x3

# =============================================================================
# LOGGING
# =============================================================================

logging.getLogger("can").setLevel(logging.ERROR)
logger = logging.getLogger(__name__)


def _log_tx(msg: can.Message, context=None):
    """Log transmitted CAN message."""
    id_str = f"{msg.arbitration_id:08X}" if msg.is_extended_id else f"{msg.arbitration_id:03X}"
    data = " ".join(f"{b:02X}" for b in msg.data)
    line = f"Tx {id_str} {msg.dlc} {data}"
    if context:
        context.log(line)
    else:
        logger.debug(line)


def _log_rx(msg: can.Message, context=None):
    """Log received CAN message."""
    if msg.arbitration_id == DEFAULT_ECU_RESPONSE_ID:
        id_str = f"{msg.arbitration_id:08X}" if msg.is_extended_id else f"{msg.arbitration_id:03X}"
        data = " ".join(f"{b:02X}" for b in msg.data)
        line = f"Rx {id_str} {msg.dlc} {data}"
        if context:
            context.log(line)
        else:
            logger.debug(line)


# =============================================================================
# BUS MANAGEMENT (CAN-001)
# =============================================================================

def _open_bus(can_interface: str, bitrate: int, is_extended: bool = False) -> can.Bus:
    """Open CAN bus with support for extended IDs."""
    iface = can_interface.strip()
    
    try:
        if iface.upper().startswith("PCAN"):
            return can.Bus(interface="pcan", channel=iface, bitrate=bitrate, fd=False)
        if iface.lower().startswith("can"):
            return can.Bus(interface="socketcan", channel=iface, bitrate=bitrate)
        raise ValueError(f"Unsupported CAN interface: {iface}")
    except Exception as e:
        logger.error(f"Failed to open CAN bus: {e}")
        raise


def _validate_bus(bus: Optional[can.Bus], context=None) -> bool:
    """Validate that bus is connected and operational."""
    if bus is None:
        if context:
            context.log("CAN bus is None", "ERROR")
        else:
            logger.error("CAN bus is None")
        return False
    
    try:
        # Check if bus has required attributes
        if not hasattr(bus, 'send') or not hasattr(bus, 'recv'):
            if context:
                context.log("CAN bus missing required attributes", "ERROR")
            else:
                logger.error("CAN bus missing required attributes")
            return False
        
        # Check bus state if supported
        if hasattr(bus, 'state'):
            try:
                if bus.state.name == 'ERROR':
                    if context:
                        context.log("CAN bus is in ERROR state", "WARN")
                    else:
                        logger.warning("CAN bus is in ERROR state")
                    return False
            except:
                pass
        
        return True
    except Exception as e:
        if context:
            context.log(f"Bus validation error: {e}", "ERROR")
        else:
            logger.error(f"Bus validation error: {e}")
        return False


# =============================================================================
# CAN FRAME HELPERS (PROTO-006)
# =============================================================================

def _send_can_frame(
    bus: can.Bus, 
    arbitration_id: int, 
    data: list, 
    is_extended_id: bool = False,
    context=None
) -> bool:
    """Send CAN frame with support for 29-bit extended IDs."""
    if not _validate_bus(bus, context):
        return False
    
    padded_data = data[:]
    while len(padded_data) < 8:
        padded_data.append(0x00)
    
    msg = can.Message(
        arbitration_id=arbitration_id, 
        data=bytearray(padded_data[:8]), 
        is_extended_id=is_extended_id
    )
    
    _log_tx(msg, context)
    
    try:
        bus.send(msg)
        return True
    except can.CanError as e:
        if context:
            context.log(f"CAN send error: {e}", "ERROR")
        else:
            logger.error(f"CAN send error: {e}")
        return False


def _receive_single_can_frame(
    bus: can.Bus, 
    response_id: int, 
    timeout: float = 0.5, 
    is_extended_id: bool = False,
    context=None
) -> Optional[can.Message]:
    """Receive a single CAN frame with timeout."""
    if not _validate_bus(bus, context):
        return None
    
    start_time = time.time()
    while time.time() - start_time < timeout:
        remaining = timeout - (time.time() - start_time)
        if remaining <= 0:
            break
        
        try:
            msg = bus.recv(timeout=min(0.1, remaining))
            if msg and msg.arbitration_id == response_id and msg.is_extended_id == is_extended_id:
                _log_rx(msg, context)
                return msg
        except can.CanError as e:
            if context:
                context.log(f"CAN receive error: {e}", "ERROR")
            else:
                logger.error(f"CAN receive error: {e}")
            continue
    
    return None


# =============================================================================
# ISO-TP PROTOCOL IMPLEMENTATION
# =============================================================================

def _receive_isotp_response(
    bus: can.Bus, 
    response_id: int, 
    timeout: float = DEFAULT_TIMEOUT, 
    is_extended_id: bool = False,
    context=None
) -> Optional[List[int]]:
    """
    Receive ISO-TP response with multi-frame support.
    
    Handles:
    - Single Frame (SF)
    - First Frame (FF) + Consecutive Frames (CF)
    - Flow Control (FC)
    """
    start_time = time.time()
    full_response_data: List[int] = []
    expect_consecutive_frames = False
    seq_number_expected = 1
    total_uds_length = 0

    while time.time() - start_time < timeout:
        remaining = timeout - (time.time() - start_time)
        if remaining <= 0:
            break
            
        msg = _receive_single_can_frame(bus, response_id, timeout=min(0.5, remaining), 
                                        is_extended_id=is_extended_id, context=context)
        if not msg:
            continue

        pci_type = (msg.data[0] & 0xF0) >> 4

        if pci_type == ISO_TP_SINGLE_FRAME:  # Single Frame
            uds_length = msg.data[0] & 0x0F
            full_response_data = list(msg.data[1:1 + uds_length])
            break

        elif pci_type == ISO_TP_FIRST_FRAME:  # First Frame
            total_uds_length = ((msg.data[0] & 0x0F) << 8) + msg.data[1]
            full_response_data = list(msg.data[2:])
            expect_consecutive_frames = True
            seq_number_expected = 1

            # PROTO-001: Send Flow Control to ECU response ID (FIXED)
            fc_frame = [0x30, 0x00, 0x00] + [0x00] * 5
            time.sleep(0.01)
            if not _send_can_frame(bus, response_id, fc_frame, is_extended_id, context):
                if context:
                    context.log("Failed to send Flow Control", "ERROR")
                return None
            continue

        elif expect_consecutive_frames and pci_type == ISO_TP_CONSECUTIVE_FRAME:  # Consecutive Frame
            seq_number = msg.data[0] & 0x0F
            if seq_number != seq_number_expected:
                if context:
                    context.log(f"Sequence number mismatch: expected {seq_number_expected}, got {seq_number}", "ERROR")
                return None

            full_response_data.extend(msg.data[1:])
            seq_number_expected = (seq_number_expected + 1) % 16

            if len(full_response_data) >= total_uds_length:
                full_response_data = full_response_data[:total_uds_length]
                break

    return full_response_data or None


def _send_isotp_request(
    bus: can.Bus, 
    arbitration_id: int, 
    data: List[int], 
    is_extended_id: bool = False,
    context=None
) -> bool:
    """
    Send ISO-TP request with multi-frame support.
    
    Handles:
    - Single Frame (SF) for small messages
    - First Frame (FF) + Consecutive Frames (CF) for large messages
    """
    total_len = len(data)
    
    # Single Frame (up to 7 bytes)
    if total_len <= 7:
        sf = [total_len] + data + [0x00] * (7 - total_len)
        return _send_can_frame(bus, arbitration_id, sf, is_extended_id, context)

    # First Frame (8+ bytes)
    ff_data = [0x10 | ((total_len >> 8) & 0x0F), total_len & 0xFF] + data[:6]
    if not _send_can_frame(bus, arbitration_id, ff_data, is_extended_id, context):
        return False

    # PROTO-003: Receive Flow Control with retry
    fc_msg = None
    for attempt in range(FLOW_CONTROL_RETRY_COUNT):
        fc_msg = _receive_single_can_frame(bus, arbitration_id, timeout=FLOW_CONTROL_TIMEOUT, 
                                          is_extended_id=is_extended_id, context=context)
        if fc_msg and ((fc_msg.data[0] & 0xF0) >> 4) == ISO_TP_FLOW_CONTROL:
            if context:
                context.log(f"Flow Control received on attempt {attempt + 1}")
            break
        if context:
            context.log(f"Flow Control attempt {attempt + 1} failed, retrying...", "WARN")
        time.sleep(0.1 * (attempt + 1))
    
    if not fc_msg or ((fc_msg.data[0] & 0xF0) >> 4) != ISO_TP_FLOW_CONTROL:
        if context:
            context.log("Failed to receive Flow Control after retries", "ERROR")
        return False

    # Parse STmin from Flow Control
    stmin = fc_msg.data[2] & 0x7F
    if stmin <= 0x7F:
        delay_ms = stmin  # Milliseconds
    else:
        delay_ms = (stmin & 0x0F) * 100  # Microseconds (convert to ms)

    # Send Consecutive Frames
    remaining_data = data[6:]
    seq = 1
    while remaining_data:
        cf_data_len = min(7, len(remaining_data))
        cf = [0x20 | (seq % 16)] + remaining_data[:cf_data_len]
        if not _send_can_frame(bus, arbitration_id, cf, is_extended_id, context):
            return False
        
        remaining_data = remaining_data[cf_data_len:]
        seq += 1
        
        if remaining_data:
            time.sleep(delay_ms / 1000.0)  # Convert to seconds

    return True


# =============================================================================
# UDS PROTOCOL HELPERS
# =============================================================================

def _send_uds_request(
    bus: can.Bus,
    tester_id: int,
    response_id: int,
    sid: int,
    sub_payload: List[int],
    expected_positive_sid: int,
    is_extended_id: bool = False,
    timeout: float = DEFAULT_TIMEOUT,
    context=None
) -> Optional[List[int]]:
    """Send UDS request and wait for response."""
    uds_payload = [sid] + sub_payload

    if len(uds_payload) <= 7:
        # Single Frame
        sf = [len(uds_payload)] + uds_payload + [0x00] * (7 - len(uds_payload))
        if not _send_can_frame(bus, tester_id, sf, is_extended_id, context):
            return None
    else:
        # Multi-frame
        if not _send_isotp_request(bus, tester_id, uds_payload, is_extended_id, context):
            return None

    response = _receive_isotp_response(bus, response_id, timeout, is_extended_id, context)
    if response and response[0] == expected_positive_sid:
        return response
    
    # Check for negative response
    if response and len(response) >= 3 and response[0] == 0x7F:
        service = response[1]
        nrc = response[2]
        if context:
            context.log(f"UDS Negative Response: 7F {service:02X} {nrc:02X}", "WARN")
    
    return None


def _extended_diagnostic_session(
    bus: can.Bus,
    tester_id: int = DEFAULT_TESTER_ID,
    response_id: int = DEFAULT_ECU_RESPONSE_ID,
    is_extended_id: bool = False,
    context=None
) -> bool:
    """Switch ECU to extended diagnostic session (0x10 03)."""
    response = _send_uds_request(
        bus,
        tester_id,
        response_id,
        sid=0x10,
        sub_payload=[0x03],
        expected_positive_sid=0x50,
        timeout=2.0,
        is_extended_id=is_extended_id,
        context=context
    )
    return bool(response and len(response) >= 2 and response[1] == 0x03)


# =============================================================================
# MAIN FUNCTION
# =============================================================================

def read_vin(
    can_interface: str,
    bitrate: int,
    context=None,
    progress=None,
    timeout: float = DEFAULT_TIMEOUT,
    tester_id: int = DEFAULT_TESTER_ID,
    response_id: int = DEFAULT_ECU_RESPONSE_ID,
    is_extended_id: bool = False,
    **kwargs
) -> Dict[str, Any]:
    """
    Read VIN from ECU using UDS ReadDataByIdentifier (22 F1 90).
    
    Args:
        can_interface: CAN interface name
        bitrate: CAN bitrate
        context: Runner context for logging and checkpoint
        progress: Progress callback
        timeout: Timeout in seconds
        tester_id: CAN ID for tester requests
        response_id: CAN ID for ECU responses
        is_extended_id: Use 29-bit extended IDs
        **kwargs: Additional arguments
    
    Returns:
        Dictionary with keys:
        - vin: VIN string or None if failed
        - raw: Raw response data for debugging
    
    Raises:
        RuntimeError: If VIN read fails
    """
    bus = None
    raw: Dict[str, Any] = {}

    def _log_line(msg: str, level: str = "INFO"):
        if context:
            context.log(msg, level)
        else:
            getattr(logger, level.lower(), logger.info)(msg)

    try:
        if progress:
            progress(5, f"Opening CAN ({can_interface}, {bitrate})")
        
        # Open CAN bus
        bus = _open_bus(can_interface, bitrate, is_extended_id)
        raw["bus"] = {"interface": can_interface, "bitrate": bitrate, "extended": is_extended_id}

        # CAN-001: Validate bus
        if not _validate_bus(bus, context):
            raise RuntimeError("CAN bus validation failed")

        if context:
            context.checkpoint()
            context.log("Starting extended diagnostic session (0x10 03)")

        # Switch to extended diagnostic session
        if not _extended_diagnostic_session(bus, tester_id, response_id, is_extended_id, context):
            raise RuntimeError("Extended diagnostic session failed")

        if progress:
            progress(40, "Requesting VIN (22 F1 90)")
        if context:
            context.log("Sending UDS request 22 F1 90")

        # Read VIN (DID F190)
        response = _send_uds_request(
            bus,
            tester_id,
            response_id,
            sid=0x22,
            sub_payload=[0xF1, 0x90],
            expected_positive_sid=0x62,
            timeout=timeout,
            is_extended_id=is_extended_id,
            context=context,
        )

        raw["uds_response"] = response

        if response and len(response) >= 3 and response[1] == 0xF1 and response[2] == 0x90:
            vin_bytes = response[3:]
            vin_str = "".join(chr(b) if 32 <= b <= 126 else "?" for b in vin_bytes).strip().upper()

            if context:
                context.log(f"VIN read: {vin_str}")
                context.checkpoint()
            if progress:
                progress(100, f"VIN: {vin_str}")

            return {"vin": vin_str, "raw": raw}

        raise RuntimeError("No valid VIN (F190) response from ECU")

    except can.CanError as e:
        _log_line(f"CAN error: {e}", "ERROR")
        raise RuntimeError(f"CAN error: {e}") from e
    except Exception as e:
        _log_line(f"Error: {e}", "ERROR")
        raise
    finally:
        if bus:
            try:
                bus.shutdown()
                _log_line("CAN bus shutdown.")
            except Exception as e:
                _log_line(f"Error shutting down CAN bus: {e}", "WARN")