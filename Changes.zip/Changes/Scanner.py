Scanner.py

# -*- coding: utf-8 -*-
"""
NIRIX STATION SCANNER (BACKEND – OpenCV)

RESPONSIBILITY
──────────────
This module is used ONLY by the backend `/api/scan/*` endpoints to talk to a
fixed station camera (USB / built‑in) using OpenCV.

- Front-end scanner (phone/tablet/desktop browser) uses html5-qrcode in tests.html.
- Backend scanner is used mainly on PC stations where OpenCV has direct access
  to a local camera and you want scanning without browser camera permission.

PUBLIC API
──────────
- start_scan(kind: "text"|"vin"|"hex" = "text", timeout_sec: int|None = None) -> ScanSession
- get_scan(scan_id: str) -> Optional[ScanSession]
- cancel_scan(scan_id: str) -> bool
- cleanup_scans(max_age_sec: int = 300) -> int
- get_scan_frame_jpeg(scan_id: str) -> Optional[bytes]

Version: 2.1.0
Last Updated: 2026-02-22

FIXES IN v2.1.0
────────────────
- SCAN-001: Fixed memory leak in preview mode with size limiting
- SCAN-002: Added timeout for camera acquisition
- SCAN-003: Added input validation for camera index
- SCAN-004: Added session limit to prevent unbounded growth
- SCAN-005: Optimized frame decoding with frame skipping
- SCAN-006: Added frame buffer clearing on camera start
- SCAN-007: Added retry logic for camera opening
"""

from __future__ import annotations

import os
import time
import uuid
import threading
import logging
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Tuple

import cv2
import numpy as np

# =============================================================================
# LOGGING
# =============================================================================

logger = logging.getLogger(__name__)


def _log_info(message: str):
    logger.info(f"[SCANNER] {message}")


def _log_warn(message: str):
    logger.warning(f"[SCANNER] {message}")


def _log_error(message: str):
    logger.error(f"[SCANNER] {message}")


def _log_debug(message: str):
    logger.debug(f"[SCANNER] {message}")


# =============================================================================
# CONFIG (SCAN-003)
# =============================================================================

def _validate_camera_index(index_str: str) -> int:
    """Validate camera index is within reasonable range."""
    try:
        index = int(index_str)
        if index < 0 or index > 10:  # Reasonable range
            _log_warn(f"Camera index {index} out of range (0-10), using 0")
            return 0
        return index
    except ValueError:
        _log_warn(f"Invalid camera index '{index_str}', using 0")
        return 0


CAM_INDEX = _validate_camera_index(os.getenv("NIRIX_SCAN_CAMERA_INDEX", "0"))
DEFAULT_TIMEOUT_SEC = int(os.getenv("NIRIX_SCAN_TIMEOUT_SEC", "20"))

PREVIEW_ENABLED = os.getenv("NIRIX_SCAN_PREVIEW_ENABLED", "true").lower() in ("1", "true", "yes")
PREVIEW_WIDTH = int(os.getenv("NIRIX_SCAN_PREVIEW_WIDTH", "640"))
PREVIEW_QUALITY = int(os.getenv("NIRIX_SCAN_PREVIEW_QUALITY", "75"))
PREVIEW_MAX_FPS = float(os.getenv("NIRIX_SCAN_PREVIEW_MAX_FPS", "8"))

# Session limits (SCAN-004)
MAX_SCAN_SESSIONS = int(os.getenv("NIRIX_SCAN_MAX_SESSIONS", "100"))
MAX_PREVIEW_FRAME_SIZE = 100 * 1024  # 100KB max preview frame

# Enforce single camera access process-wide
_CAMERA_LOCK = threading.Lock()


def _cv_cap_backend() -> int:
    """
    Optional VideoCapture backend selection for Windows/Linux camera quirks.
    """
    name = (os.getenv("NIRIX_SCAN_CAP_BACKEND", "") or "").strip().upper()
    mapping = {
        "DSHOW": getattr(cv2, "CAP_DSHOW", 0),
        "MSMF": getattr(cv2, "CAP_MSMF", 0),
        "V4L2": getattr(cv2, "CAP_V4L2", 0),
        "ANY": getattr(cv2, "CAP_ANY", 0),
    }
    return mapping.get(name, 0)


# Prefer OpenCV barcode module if available (opencv-contrib-python)
_BARCODE_DETECTOR = None
try:
    # Depending on build, one of these exists
    if hasattr(cv2, "barcode_BarcodeDetector"):
        _BARCODE_DETECTOR = cv2.barcode_BarcodeDetector()  # type: ignore[attr-defined]
    elif hasattr(cv2, "barcode") and hasattr(cv2.barcode, "BarcodeDetector"):
        _BARCODE_DETECTOR = cv2.barcode.BarcodeDetector()  # type: ignore[attr-defined]
except Exception as e:
    _log_warn(f"Barcode detector not available: {e}")
    _BARCODE_DETECTOR = None

_QR_DETECTOR = cv2.QRCodeDetector()


# =============================================================================
# DATA MODEL
# =============================================================================

@dataclass
class ScanSession:
    """In-memory scan session state."""
    scan_id: str
    status: str = "running"  # running|found|timeout|cancelled|error|busy
    value: Optional[str] = None
    error: Optional[str] = None
    created_at: float = field(default_factory=time.time)

    cancel_event: threading.Event = field(default_factory=threading.Event, repr=False)

    # Optional preview support (latest JPEG frame) - SCAN-001
    last_frame_jpeg: Optional[bytes] = None
    last_frame_at: Optional[float] = None
    _preview_frame_count: int = 0  # Track frames for debugging

    # Internal lock for safe updates
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def set_status(self, status: str, *, error: Optional[str] = None):
        with self._lock:
            self.status = status
            if error is not None:
                self.error = error
            _log_debug(f"Session {self.scan_id} status -> {status}")

    def set_value_found(self, value: str):
        with self._lock:
            self.value = value
            self.status = "found"
            _log_info(f"Session {self.scan_id} found value: {value}")

    def set_preview_frame(self, jpg: bytes):
        """Set preview frame with size limiting (SCAN-001)."""
        with self._lock:
            # Limit frame size
            if len(jpg) > MAX_PREVIEW_FRAME_SIZE:
                # Compress further if too large
                try:
                    # Decode and re-encode with lower quality
                    nparr = np.frombuffer(jpg, np.uint8)
                    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                    if img is not None:
                        # Reduce quality
                        _, compressed = cv2.imencode(
                            '.jpg', img, 
                            [int(cv2.IMWRITE_JPEG_QUALITY), 30]  # Lower quality
                        )
                        jpg = compressed.tobytes()
                        _log_debug(f"Compressed preview frame from {len(jpg)} to {len(compressed)} bytes")
                except Exception as e:
                    _log_error(f"Frame compression error: {e}")
                    # If compression fails, keep original but warn
                    _log_warn(f"Preview frame size {len(jpg)} bytes exceeds limit")
            
            self.last_frame_jpeg = jpg
            self.last_frame_at = time.time()
            self._preview_frame_count += 1


_SCANS: Dict[str, ScanSession] = {}
_SCANS_LOCK = threading.Lock()


# =============================================================================
# SESSION LIMIT ENFORCEMENT (SCAN-004)
# =============================================================================

def _enforce_session_limit():
    """Remove oldest session if limit exceeded."""
    with _SCANS_LOCK:
        if len(_SCANS) >= MAX_SCAN_SESSIONS:
            # Find oldest session
            oldest = min(
                _SCANS.items(), 
                key=lambda x: x[1].created_at
            )[0]
            _log_info(f"Session limit reached, removing oldest session {oldest}")
            _SCANS.pop(oldest, None)


# =============================================================================
# HELPERS
# =============================================================================

def _postprocess(value: str, kind: str) -> str:
    """
    Post-process decoded text based on `kind`:
      - "vin": uppercase, strip spaces
      - "hex": uppercase, strip 0x prefix and spaces
      - default: strip
    """
    s = (value or "").strip()
    kind = (kind or "text").strip().lower()

    if kind == "vin":
        s = s.upper().replace(" ", "")
        # Basic VIN validation (length, invalid chars)
        if len(s) != 17:
            _log_warn(f"VIN length {len(s)} != 17")
        if any(c in s for c in "IOQ"):
            _log_warn("VIN contains invalid characters I/O/Q")
    elif kind == "hex":
        s = s.strip().upper()
        if s.startswith("0X"):
            s = s[2:]
        s = s.replace(" ", "")
        # Validate hex
        if not all(c in "0123456789ABCDEF" for c in s):
            _log_warn(f"Invalid hex characters in: {s}")
    else:
        s = s.strip()
    
    return s


def _try_decode_barcode(frame) -> Optional[str]:
    """
    Decode using OpenCV barcode detector (if available).
    Handles minor API differences across builds.
    """
    if _BARCODE_DETECTOR is None:
        return None

    try:
        # Most builds return: ok, decoded_info, decoded_type, points
        out = _BARCODE_DETECTOR.detectAndDecode(frame)  # type: ignore
        if not isinstance(out, tuple) or len(out) < 2:
            return None

        ok = bool(out[0])
        decoded_info = out[1]

        if ok and decoded_info:
            # decoded_info is typically a list of strings
            if isinstance(decoded_info, (list, tuple)):
                for v in decoded_info:
                    if v:
                        return str(v)
            # some builds might return a single string
            if isinstance(decoded_info, str) and decoded_info:
                return decoded_info
    except Exception as e:
        _log_debug(f"Barcode decode error: {e}")
        return None

    return None


def _try_decode_qr(frame) -> Optional[str]:
    """Decode using OpenCV QRCodeDetector (always available)."""
    try:
        data, points, _ = _QR_DETECTOR.detectAndDecode(frame)
        if data:
            return str(data)
    except Exception as e:
        _log_debug(f"QR decode error: {e}")
        return None
    return None


def _decode_frame(frame) -> Optional[str]:
    """
    Decode a single frame using:
      1) OpenCV barcode detector (if available)
      2) OpenCV QRCodeDetector (always available)
    """
    v = _try_decode_barcode(frame)
    if v:
        return v
    return _try_decode_qr(frame)


def _encode_preview_jpeg(frame) -> Optional[bytes]:
    """
    Encode frame as JPEG for optional preview.
    Resizes for bandwidth/CPU control.
    """
    if frame is None:
        return None

    try:
        img = frame

        if PREVIEW_WIDTH and PREVIEW_WIDTH > 0:
            h, w = img.shape[:2]
            if w > PREVIEW_WIDTH:
                scale = PREVIEW_WIDTH / float(w)
                new_w = PREVIEW_WIDTH
                new_h = int(h * scale)
                img = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_AREA)

        quality = max(10, min(95, int(PREVIEW_QUALITY)))
        ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
        if not ok:
            return None
        return buf.tobytes()
    except Exception as e:
        _log_debug(f"JPEG encoding error: {e}")
        return None


# =============================================================================
# CAMERA ACQUISITION HELPERS (SCAN-002, SCAN-006, SCAN-007)
# =============================================================================

def _acquire_camera_with_timeout(timeout: float = 5.0) -> bool:
    """
    Acquire camera lock with timeout.
    
    Args:
        timeout: Maximum time to wait in seconds
    
    Returns:
        True if lock acquired, False otherwise
    """
    start = time.time()
    while time.time() - start < timeout:
        if _CAMERA_LOCK.acquire(blocking=False):
            return True
        time.sleep(0.1)
    return False


def _clear_camera_buffer(cap, num_frames: int = 5):
    """Discard initial frames to get stable image (SCAN-006)."""
    for i in range(num_frames):
        cap.read()
        time.sleep(0.05)
    _log_debug(f"Cleared {num_frames} frames from camera buffer")


def _open_camera_with_retry(index: int, backend: int, max_retries: int = 3) -> Optional[cv2.VideoCapture]:
    """
    Open camera with retry logic (SCAN-007).
    
    Args:
        index: Camera index
        backend: OpenCV backend
        max_retries: Maximum number of retry attempts
    
    Returns:
        VideoCapture object or None if failed
    """
    for attempt in range(max_retries):
        try:
            if backend:
                cap = cv2.VideoCapture(index, backend)
            else:
                cap = cv2.VideoCapture(index)
            
            if cap and cap.isOpened():
                _log_info(f"Camera opened on attempt {attempt + 1}")
                return cap
            
            if attempt < max_retries - 1:
                delay = 0.5 * (attempt + 1)  # Increasing delay
                _log_warn(f"Failed to open camera, retrying in {delay:.1f}s (attempt {attempt + 1})")
                time.sleep(delay)
                
        except Exception as e:
            if attempt == max_retries - 1:
                _log_error(f"Failed to open camera after {max_retries} attempts: {e}")
                return None
            time.sleep(0.5)
    
    return None


# =============================================================================
# PUBLIC API
# =============================================================================

def start_scan(kind: str = "text", timeout_sec: Optional[int] = None) -> ScanSession:
    """
    Start a new scan session.

    Args:
        kind: "text" | "vin" | "hex"
        timeout_sec: optional timeout override (seconds)

    Returns:
        ScanSession with a unique scan_id.
    """
    scan_id = f"scan_{uuid.uuid4().hex[:10]}"
    session = ScanSession(scan_id=scan_id)

    with _SCANS_LOCK:
        # SCAN-004: Enforce session limit
        _enforce_session_limit()
        _SCANS[scan_id] = session

    try:
        tsec = int(timeout_sec) if timeout_sec is not None else DEFAULT_TIMEOUT_SEC
    except Exception:
        tsec = DEFAULT_TIMEOUT_SEC
    tsec = max(1, tsec)

    def worker():
        # SCAN-002: Try to acquire camera with timeout
        if not _acquire_camera_with_timeout(timeout=5.0):
            session.set_status("busy", error="Camera is busy (acquisition timeout)")
            _log_warn(f"Session {scan_id} failed to acquire camera lock")
            return

        cap = None
        try:
            backend = _cv_cap_backend()
            # SCAN-007: Open camera with retry
            cap = _open_camera_with_retry(CAM_INDEX, backend)
            
            if not cap:
                session.set_status("error", error=f"Cannot open camera index {CAM_INDEX} after retries")
                return

            # SCAN-006: Clear camera buffer
            _clear_camera_buffer(cap, num_frames=5)

            end = time.time() + tsec
            last_preview_emit = 0.0
            preview_min_interval = 1.0 / max(1.0, float(PREVIEW_MAX_FPS))
            
            # SCAN-005: Frame skipping
            frame_count = 0
            decode_interval = 3  # Decode every 3rd frame

            while time.time() < end and not session.cancel_event.is_set():
                ok, frame = cap.read()
                if not ok or frame is None:
                    time.sleep(0.05)
                    continue

                frame_count += 1

                # SCAN-005: Only decode every N frames
                if frame_count % decode_interval == 0:
                    val = _decode_frame(frame)
                    if val:
                        session.set_value_found(_postprocess(val, kind))
                        return

                # Optional preview capture (SCAN-001)
                if PREVIEW_ENABLED:
                    now = time.time()
                    if (now - last_preview_emit) >= preview_min_interval:
                        jpg = _encode_preview_jpeg(frame)
                        if jpg:
                            session.set_preview_frame(jpg)
                        last_preview_emit = now

                time.sleep(0.02)

            if session.cancel_event.is_set():
                session.set_status("cancelled")
                _log_info(f"Session {scan_id} cancelled by user")
            else:
                session.set_status("timeout")
                _log_info(f"Session {scan_id} timed out after {tsec}s")

        except Exception as e:
            _log_error(f"Session {scan_id} error: {e}")
            session.set_status("error", error=str(e))

        finally:
            try:
                if cap is not None:
                    cap.release()
                    _log_debug(f"Session {scan_id} released camera")
            finally:
                _CAMERA_LOCK.release()
                _log_debug(f"Session {scan_id} released camera lock")

    threading.Thread(target=worker, daemon=True).start()
    return session


def get_scan(scan_id: str) -> Optional[ScanSession]:
    """Get scan session state by ID."""
    with _SCANS_LOCK:
        return _SCANS.get(scan_id)


def get_scan_frame_jpeg(scan_id: str) -> Optional[bytes]:
    """
    Return latest preview JPEG bytes if available (PREVIEW_ENABLED must be true).
    Safe to call even if preview is disabled (returns None).
    """
    s = get_scan(scan_id)
    if not s:
        return None
    with s._lock:
        return s.last_frame_jpeg


def cancel_scan(scan_id: str) -> bool:
    """Request cancellation of a scan session."""
    s = get_scan(scan_id)
    if not s:
        return False
    s.cancel_event.set()
    _log_info(f"Cancellation requested for session {scan_id}")
    return True


def cleanup_scans(max_age_sec: int = 300) -> int:
    """
    Remove old scan sessions from memory.
    
    Args:
        max_age_sec: Maximum age in seconds
    
    Returns:
        Number of sessions removed
    """
    now = time.time()
    removed = 0
    with _SCANS_LOCK:
        to_del = [sid for sid, s in _SCANS.items() if (now - s.created_at) > max_age_sec]
        for sid in to_del:
            _SCANS.pop(sid, None)
            removed += 1
    
    if removed > 0:
        _log_info(f"Cleaned up {removed} old scan sessions")
    return removed


def get_scan_stats() -> Dict[str, Any]:
    """Get scanner statistics."""
    with _SCANS_LOCK:
        active = [s for s in _SCANS.values() if s.status == "running"]
        return {
            "total_sessions": len(_SCANS),
            "active_sessions": len(active),
            "max_sessions": MAX_SCAN_SESSIONS,
            "camera_index": CAM_INDEX,
            "preview_enabled": PREVIEW_ENABLED,
            "sessions": [
                {
                    "id": s.scan_id,
                    "status": s.status,
                    "age_seconds": time.time() - s.created_at,
                    "has_value": s.value is not None,
                    "preview_frames": s._preview_frame_count if PREVIEW_ENABLED else 0
                }
                for s in list(_SCANS.values())[:10]  # Show only first 10
            ]
        }


def test_camera() -> Tuple[bool, str]:
    """
    Test camera connectivity.
    
    Returns:
        Tuple of (success, message)
    """
    try:
        cap = cv2.VideoCapture(CAM_INDEX)
        if not cap or not cap.isOpened():
            return False, f"Cannot open camera index {CAM_INDEX}"
        
        ok, frame = cap.read()
        cap.release()
        
        if not ok or frame is None:
            return False, "Cannot read frame from camera"
        
        return True, f"Camera {CAM_INDEX} working, frame size: {frame.shape}"
    except Exception as e:
        return False, f"Camera test failed: {e}"


# =============================================================================
# MODULE INITIALIZATION
# =============================================================================

def _init():
    """Initialize scanner module."""
    _log_info(f"Scanner v2.1.0 initialized")
    _log_info(f"Camera index: {CAM_INDEX}")
    _log_info(f"Preview enabled: {PREVIEW_ENABLED}")
    _log_info(f"Max sessions: {MAX_SCAN_SESSIONS}")
    _log_info(f"Barcode detector: {'available' if _BARCODE_DETECTOR else 'not available'}")
    _log_info(f"QR detector: available")


_init()


__all__ = [
    "ScanSession",
    "start_scan",
    "get_scan",
    "get_scan_frame_jpeg",
    "cancel_scan",
    "cleanup_scans",
    "get_scan_stats",
    "test_camera",
]