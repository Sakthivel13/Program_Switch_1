battery_voltage.py,

# -*- coding: utf-8 -*-
"""
Battery Voltage – PRODUCTION (Self-Sufficient)

Auto-run streaming entry point:
  module_name: battery_voltage
  function_name: read_battery_voltage_stream
  program_type: "stream"
  execution_mode: "stream"

Single-shot entry point:
  module_name: battery_voltage
  function_name: read_battery_voltage
  program_type: "single"
  execution_mode: "single"

UDS DID: 22 E1 42  (Battery Voltage)
CAN IDs: 0x7F0 (req), 0x7F1 (resp)

Version: 2.1.0
Last Updated: 2026-02-23

FIXES:
- TEST-002: Fixed GeneratorExit handling with proper raise
- AR-002: Added rate limiting configuration
- AR-ERR-004: Added circuit breaker for repeated failures
- LP-003: Added signal name validation
- CAN-001: Added bus validation
- PROTO-006: Added 29-bit CAN ID support
"""

from __future__ import annotations

import time
import logging
from typing import Dict, Any, Optional, Generator, List
from dataclasses import dataclass

import can

# =============================================================================
# CONSTANTS
# =============================================================================

DEFAULT_TESTER_ID = 0x7F0
DEFAULT_RESPONSE_ID = 0x7F1
DEFAULT_TIMEOUT = 2.0
DEFAULT_INTERVAL_SEC = 0.4
MAX_FREQUENCY_HZ = 10
MAX_CONSECUTIVE_ERRORS = 5
MAX_STREAM_DURATION_SEC = 3600  # 1 hour

# =============================================================================
# LOGGING
# =============================================================================

logging.getLogger("can").setLevel(logging.ERROR)
logger = logging.getLogger(__name__)


@dataclass
class StreamConfig:
    """Configuration for stream behavior."""
    interval_sec: float = DEFAULT_INTERVAL_SEC
    max_frequency_hz: int = MAX_FREQUENCY_HZ
    adaptive_rate: bool = False
    max_consecutive_errors: int = MAX_CONSECUTIVE_ERRORS
    max_duration_sec: int = MAX_STREAM_DURATION_SEC
    expected_signals: List[str] = None
    
    def __post_init__(self):
        if self.expected_signals is None:
            self.expected_signals = ["battery_voltage"]
        self.min_interval = 1.0 / max(1, self.max_frequency_hz)
        self.effective_interval = max(self.interval_sec, self.min_interval)


# =============================================================================
# BUS MANAGEMENT
# =============================================================================

def _open_bus(can_interface: str, bitrate: int, is_extended: bool = False) -> Optional[can.Bus]:
    """Open CAN bus with support for extended IDs."""
    iface = (can_interface or "").strip()
    try:
        if iface.upper().startswith("PCAN"):
            return can.Bus(interface="pcan", channel=iface, bitrate=int(bitrate), fd=False)
        if iface.lower().startswith("can"):
            return can.Bus(interface="socketcan", channel=iface, bitrate=int(bitrate))
        raise ValueError(f"Unsupported CAN interface: {iface}")
    except Exception as e:
        logger.error(f"Failed to open CAN bus: {e}")
        return None


def _validate_bus(bus: Optional[can.Bus], context=None) -> bool:
    """Validate that bus is connected and operational."""
    if bus is None:
        if context:
            context.log("CAN bus is None", "ERROR")
        return False
    
    try:
        if not hasattr(bus, 'send') or not hasattr(bus, 'recv'):
            return False
        
        if hasattr(bus, 'state') and hasattr(bus.state, 'name') and bus.state.name == 'ERROR':
            return False
        
        return True
    except Exception:
        return False


def _serialize_can_message(msg: can.Message) -> Dict[str, Any]:
    """Serialize CAN message for logging."""
    return {
        "arbitration_id": f"{msg.arbitration_id:03X}",
        "is_extended_id": bool(msg.is_extended_id),
        "dlc": int(msg.dlc),
        "data": [f"{b:02X}" for b in msg.data],
        "timestamp": float(getattr(msg, "timestamp", 0.0) or 0.0),
    }


# =============================================================================
# VOLTAGE READING
# =============================================================================

def _read_voltage_once(
    bus: can.Bus,
    tester_id: int = DEFAULT_TESTER_ID,
    response_id: int = DEFAULT_RESPONSE_ID,
    is_extended_id: bool = False,
    context=None,
    progress=None
) -> Dict[str, Any]:
    """
    Send UDS ReadDataByIdentifier (22 E1 42) once and parse response.
    
    Returns:
        Dict with battery_voltage, message, raw
    """
    def log(msg: str, level: str = "INFO"):
        if context:
            context.log(msg, level)
        else:
            logger.log(getattr(logging, level), msg)

    if context:
        context.checkpoint()
        context.progress(10, "Sending UDS request (22 E1 42)")
    if progress:
        progress(10, "Sending UDS request (22 E1 42)")

    # Build request message
    req_data = [0x03, 0x22, 0xE1, 0x42, 0x00, 0x00, 0x00, 0x00]
    req = can.Message(
        arbitration_id=tester_id,
        is_extended_id=is_extended_id,
        data=req_data
    )
    
    log(f"Tx {req.arbitration_id:03X} " + " ".join(f"{b:02X}" for b in req.data))
    
    try:
        bus.send(req)
    except Exception as e:
        log(f"Failed to send CAN message: {e}", "ERROR")
        raise

    if context:
        context.progress(35, "Waiting for ECU response")

    # Wait for response
    deadline = time.time() + DEFAULT_TIMEOUT
    resp = None
    
    while time.time() < deadline:
        if context:
            context.checkpoint()

        try:
            msg = bus.recv(timeout=0.3)
        except Exception as e:
            log(f"Error receiving CAN message: {e}", "ERROR")
            continue
            
        if not msg:
            continue
        if msg.arbitration_id != response_id or msg.is_extended_id != is_extended_id:
            continue

        log(f"Rx {msg.arbitration_id:03X} " + " ".join(f"{b:02X}" for b in msg.data))
        resp = msg
        break

    if not resp:
        raise TimeoutError("No response from ECU for DID E1 42")

    # Parse response - expected format: 62 E1 42 XX ...
    if not (len(resp.data) >= 5 and resp.data[1] == 0x62 and resp.data[2] == 0xE1 and resp.data[3] == 0x42):
        return {
            "battery_voltage": None,
            "message": "Invalid response format",
            "raw": {"request": _serialize_can_message(req), "response": _serialize_can_message(resp)},
        }

    voltage = resp.data[4] * 0.1  # 0.1 V resolution
    return {
        "battery_voltage": float(voltage),
        "message": f"{voltage:.1f} V",
        "raw": {"request": _serialize_can_message(req), "response": _serialize_can_message(resp)},
    }


# =============================================================================
# SINGLE-SHOT FUNCTION
# =============================================================================

def read_battery_voltage(
    can_interface: str,
    bitrate: int,
    context=None,
    progress=None,
    tester_id: int = DEFAULT_TESTER_ID,
    response_id: int = DEFAULT_RESPONSE_ID,
    is_extended_id: bool = False,
    **kwargs
) -> Dict[str, Any]:
    """
    SINGLE-SHOT entry point.
    
    Returns:
        Dict with keys:
        - battery_voltage: float or None
        - message: status message
        - raw: raw data for debugging
    """
    bus = None
    try:
        if context:
            context.checkpoint()
            context.progress(5, "Opening CAN bus")
        if progress:
            progress(5, "Opening CAN bus")

        bus = _open_bus(can_interface, int(bitrate), is_extended_id)
        if bus is None:
            error_msg = f"Failed to open CAN bus: {can_interface}"
            if context:
                context.log(error_msg, "ERROR")
            return {
                "battery_voltage": None,
                "message": error_msg,
                "raw": None,
            }

        # CAN-001: Validate bus
        if not _validate_bus(bus, context):
            error_msg = "CAN bus validation failed"
            if context:
                context.log(error_msg, "ERROR")
            return {
                "battery_voltage": None,
                "message": error_msg,
                "raw": None,
            }

        result = _read_voltage_once(bus, tester_id, response_id, is_extended_id, context, progress)

        if context:
            if result.get("battery_voltage") is not None:
                context.progress(100, f"Battery Voltage: {result['battery_voltage']:.1f} V")
                context.progress_json({"battery_voltage": result["battery_voltage"]})
            else:
                context.progress(100, "Battery Voltage read: invalid response")

        return result

    except Exception as e:
        error_msg = f"Battery voltage read failed: {e}"
        if context:
            context.log(error_msg, "ERROR")
        return {
            "battery_voltage": None,
            "message": error_msg,
            "raw": None,
        }
    finally:
        if bus:
            try:
                bus.shutdown()
            except Exception as e:
                if context:
                    context.log(f"Error closing bus: {e}", "WARN")


# =============================================================================
# STREAMING FUNCTION
# =============================================================================

def read_battery_voltage_stream(
    can_interface: str,
    bitrate: int,
    context=None,
    progress=None,
    tester_id: int = DEFAULT_TESTER_ID,
    response_id: int = DEFAULT_RESPONSE_ID,
    is_extended_id: bool = False,
    stream_config: Optional[Dict[str, Any]] = None,
    **kwargs
) -> Generator[Dict[str, Any], None, None]:
    """
    STREAMING entry point (GENERATOR) for auto-run.

    Yields runner-compatible dicts:
      {"status": "streaming", "data": {"battery_voltage": <float>}}

    Args:
        can_interface: CAN interface name
        bitrate: CAN bitrate
        context: Runner context
        progress: Progress callback
        tester_id: CAN ID for tester requests
        response_id: CAN ID for ECU responses
        is_extended_id: Use 29-bit extended IDs
        stream_config: Configuration for stream behavior
        **kwargs: Additional arguments
    """
    # AR-002: Parse stream configuration
    config = StreamConfig(**(stream_config or {}))
    
    bus = None
    iteration = 0
    consecutive_errors = 0
    start_time = time.time()
    
    try:
        if context:
            context.checkpoint()
            context.progress(5, "Opening CAN bus")
            context.log(f"BATTERY STREAM: Starting with {can_interface} @ {bitrate} bps", "INFO")
        if progress:
            progress(5, "Opening CAN bus")

        bus = _open_bus(can_interface, int(bitrate), is_extended_id)
        if bus is None:
            error_msg = f"Failed to open CAN bus: {can_interface}"
            if context:
                context.log(error_msg, "ERROR")
            yield {
                "status": "error", 
                "data": {"error": error_msg}
            }
            return

        # CAN-001: Validate bus
        if not _validate_bus(bus, context):
            error_msg = "CAN bus validation failed"
            if context:
                context.log(error_msg, "ERROR")
            yield {
                "status": "error",
                "data": {"error": error_msg}
            }
            return

        if context:
            context.log("BATTERY STREAM: CAN bus opened successfully", "INFO")

        # Main streaming loop
        while True:
            iteration += 1
            
            # AR-ERR-004: Check max duration
            if time.time() - start_time > config.max_duration_sec:
                if context:
                    context.log(f"Stream reached max duration {config.max_duration_sec}s", "INFO")
                break
            
            if context:
                context.checkpoint()
                if iteration % 10 == 0:
                    context.log(f"BATTERY STREAM: Iteration {iteration}", "DEBUG")

            try:
                single = _read_voltage_once(bus, tester_id, response_id, is_extended_id, context, progress)
            except TimeoutError:
                # On timeout: increment error counter, yield no data
                consecutive_errors += 1
                if context:
                    context.progress(60, f"No response (error {consecutive_errors}/{config.max_consecutive_errors})")
                
                # AR-ERR-004: Stop after too many consecutive errors
                if consecutive_errors >= config.max_consecutive_errors:
                    if context:
                        context.log(f"Too many consecutive errors ({consecutive_errors}), stopping stream", "ERROR")
                    yield {
                        "status": "error",
                        "data": {"error": f"ECU not responding after {consecutive_errors} attempts"}
                    }
                    return
                
                # Adaptive rate - slow down on errors
                if config.adaptive_rate:
                    config.effective_interval = min(config.effective_interval * 1.5, 5.0)
                
                # Still yield to keep stream alive
                yield {
                    "status": "streaming",
                    "data": {}
                }
                
                # Sleep with configured interval
                if context:
                    context.sleep(config.effective_interval)
                else:
                    time.sleep(config.effective_interval)
                continue
                
            except Exception as e:
                # Unexpected error
                consecutive_errors += 1
                if context:
                    context.log(f"BATTERY STREAM: Unexpected error: {e}", "ERROR")
                
                if consecutive_errors >= config.max_consecutive_errors:
                    yield {
                        "status": "error",
                        "data": {"error": str(e)}
                    }
                    return
                
                # Back off on error
                time.sleep(1.0)
                continue

            # Success - reset error counter
            consecutive_errors = 0
            
            # Reset adaptive rate if applicable
            if config.adaptive_rate and config.effective_interval > config.min_interval:
                config.effective_interval = max(config.effective_interval * 0.9, config.min_interval)

            value = single.get("battery_voltage")
            
            # LP-003: Validate expected signals
            if value is not None:
                if context:
                    context.progress(100, f"Battery Voltage: {value:.1f} V")
                    if iteration % 5 == 0:
                        context.log(f"BATTERY STREAM: Read {value:.1f}V (iteration {iteration})", "INFO")
                if progress:
                    progress(100, f"Battery Voltage: {value:.1f} V")

                # YIELD for runner → service.on_stream_data → DB persist
                yield {
                    "status": "streaming", 
                    "data": {"battery_voltage": value}
                }
            else:
                # Invalid frame
                if context:
                    context.log("BATTERY STREAM: Invalid response received", "WARN")
                yield {
                    "status": "streaming", 
                    "data": {}
                }

            # Sleep with configured interval
            if context:
                context.sleep(config.effective_interval)
            else:
                time.sleep(config.effective_interval)

    except GeneratorExit:
        # TEST-002: Re-raise to properly close generator (FIXED)
        if context:
            context.log("BATTERY STREAM: Generator closed", "INFO")
        raise
    except Exception as e:
        if context:
            context.log(f"BATTERY STREAM: Fatal error: {e}", "ERROR")
        yield {
            "status": "error", 
            "data": {"error": str(e)}
        }
    finally:
        if context:
            context.log("BATTERY STREAM: Shutting down", "INFO")
        if bus:
            try:
                bus.shutdown()
                if context:
                    context.log("BATTERY STREAM: CAN bus closed", "INFO")
            except Exception as e:
                if context:
                    context.log(f"BATTERY STREAM: Error closing bus: {e}", "ERROR")