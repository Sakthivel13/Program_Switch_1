can_utils.py

# -*- coding: utf-8 -*-
"""
CAN UTILITIES (FINAL – PRODUCTION READY, APP.SCHEMA SAFE)

Responsibilities:
✔ Resolve CAN configuration from DB (app.config)
✔ Open / close CAN bus safely
✔ Provide reusable CAN helpers for diagnostic services & test programs
✔ No test-specific logic (VIN/DTC/etc.)
✔ Compatible with python-can
✔ PostgreSQL UPSERT safe

Expected DB table:
  app.config(key_name TEXT UNIQUE, value_text TEXT)

Expected keys:
  - can_backend   : PCAN | SOCKETCAN   (optional; default PCAN)
  - can_interface : PCAN_USBBUS1 | can0 (optional; default PCAN_USBBUS1)
  - can_bitrate   : 500000             (optional; default 500000)

Version: 2.1.0
Last Updated: 2026-02-22

FIXES IN v2.1.0
────────────────
- CAN-001: Added bus state validation before operations
- CAN-002: Fixed silent configuration failures with proper error logging
- CAN-003: Added connection pooling for CAN bus instances
- CAN-004: Added input validation for channel names
- CAN-005: Added timeout handling for bus operations
"""

from __future__ import annotations

import os
import re
import time
import logging
import threading
from typing import Optional, Dict, Any, Tuple
from contextlib import contextmanager

import can
from can import interface, Bus, Message

from database import query_one, execute

# =============================================================================
# LOGGING
# =============================================================================

logger = logging.getLogger(__name__)


def _log_info(message: str):
    logger.info(f"[CAN_UTILS] {message}")


def _log_warn(message: str):
    logger.warning(f"[CAN_UTILS] {message}")


def _log_error(message: str):
    logger.error(f"[CAN_UTILS] {message}")


def _log_debug(message: str):
    logger.debug(f"[CAN_UTILS] {message}")


# =============================================================================
# EXCEPTIONS
# =============================================================================

class CanError(Exception):
    """Base class for CAN errors."""
    pass


class CanTimeoutError(CanError):
    """Timeout waiting for response."""
    pass


class CanBusError(CanError):
    """CAN bus error (disconnected, invalid state)."""
    pass


class CanConfigurationError(CanError):
    """CAN configuration error."""
    pass


# =============================================================================
# CONFIG HELPERS (POSTGRESQL SAFE) - CAN-002 FIX
# =============================================================================

def get_config_value(key: str, default: Optional[str] = None) -> Optional[str]:
    """
    Read a configuration value from DB (app.config) with error logging.
    
    Args:
        key: Configuration key
        default: Default value if not found
    
    Returns:
        Configuration value or default
    """
    try:
        row = query_one(
            "SELECT value_text FROM app.config WHERE key_name = :k",
            {"k": key},
        )
        if row and row.get("value_text") is not None:
            _log_debug(f"Read config {key}={row['value_text']}")
            return row["value_text"]
        _log_debug(f"Config {key} not found, using default: {default}")
        return default
    except Exception as e:
        _log_error(f"Failed to get config {key}: {e}")
        return default


def set_config_value(key: str, value: str, raise_on_error: bool = False) -> bool:
    """
    Insert or update config value (PostgreSQL UPSERT) with error handling.
    
    Args:
        key: Configuration key
        value: Configuration value
        raise_on_error: Whether to raise exceptions
    
    Returns:
        True if successful, False otherwise
    """
    try:
        execute(
            """
            INSERT INTO app.config (key_name, value_text)
            VALUES (:k, :v)
            ON CONFLICT (key_name)
            DO UPDATE SET value_text = EXCLUDED.value_text
            """,
            {"k": key, "v": str(value)},
        )
        _log_info(f"Set config {key}={value}")
        return True
    except Exception as e:
        error_msg = f"Failed to set config {key}={value}: {e}"
        if raise_on_error:
            _log_error(error_msg)
            raise CanConfigurationError(error_msg) from e
        else:
            _log_warn(error_msg)
            return False


# =============================================================================
# CAN CONFIG RESOLUTION
# =============================================================================

def get_can_config() -> Dict[str, Any]:
    """
    Resolve CAN configuration from DB.

    Returns:
      {
        "backend": "pcan" | "socketcan",
        "channel": "PCAN_USBBUS1" | "can0",
        "bitrate": 500000
      }
    """
    backend_raw = (get_config_value("can_backend", "PCAN") or "").strip().upper()

    interface_name = (get_config_value("can_interface", "") or "").strip()
    bitrate_text = (get_config_value("can_bitrate", "500000") or "500000").strip()

    # Defaults if not configured
    if not interface_name:
        # keep backward compatibility: if vci_mode is present, infer
        vci_mode = (get_config_value("vci_mode", "") or "").strip().lower()
        if vci_mode == "socketcan":
            interface_name = "can0"
            backend_raw = "SOCKETCAN"
        else:
            interface_name = "PCAN_USBBUS1"
            backend_raw = backend_raw or "PCAN"

    try:
        bitrate = int(bitrate_text)
    except Exception:
        _log_warn(f"Invalid bitrate '{bitrate_text}', using default 500000")
        bitrate = 500000

    if backend_raw == "SOCKETCAN":
        return {"backend": "socketcan", "channel": interface_name, "bitrate": bitrate}

    # Default: PCAN
    return {"backend": "pcan", "channel": interface_name, "bitrate": bitrate}


# =============================================================================
# CAN CHANNEL VALIDATION (CAN-004)
# =============================================================================

def validate_can_channel(channel: str, backend: str) -> Tuple[bool, str]:
    """
    Validate CAN channel name based on backend.
    
    Args:
        channel: Channel name
        backend: Backend type
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    channel = channel.strip()
    if not channel:
        return False, "Channel cannot be empty"
    
    backend = backend.lower()
    
    if backend == "pcan":
        # PCAN channels: PCAN_USBBUS1, PCAN_USBBUS2, etc.
        if not re.match(r'^PCAN_[A-Z0-9]+$', channel):
            return False, f"Invalid PCAN channel format: {channel} (should be PCAN_XXXX)"
    
    elif backend == "socketcan":
        # SocketCAN channels: can0, can1, vcan0, etc.
        if not re.match(r'^[a-z]+[0-9]+$', channel):
            return False, f"Invalid SocketCAN channel format: {channel} (should be can0, vcan0, etc.)"
    
    else:
        return False, f"Unknown backend: {backend}"
    
    return True, "OK"


# =============================================================================
# CAN BUS POOL (CAN-003)
# =============================================================================

class CanBusPool:
    """Thread-safe CAN bus connection pool."""
    
    def __init__(self, max_size: int = 5, idle_timeout: int = 300):
        """
        Initialize CAN bus pool.
        
        Args:
            max_size: Maximum number of concurrent bus connections
            idle_timeout: Seconds after which idle connections are closed
        """
        self.max_size = max_size
        self.idle_timeout = idle_timeout
        self._pool: Dict[str, Tuple[Bus, float]] = {}  # key -> (bus, last_used)
        self._usage_count: Dict[str, int] = {}
        self._lock = threading.RLock()
        self._cleanup_thread = threading.Thread(target=self._cleanup_loop, daemon=True)
        self._cleanup_thread.start()
    
    def _get_key(self, channel: str, bitrate: int, backend: str) -> str:
        """Generate pool key from parameters."""
        return f"{backend}:{channel}:{bitrate}"
    
    def acquire(self, channel: str, bitrate: int, backend: str) -> Bus:
        """
        Acquire a bus from the pool.
        
        Args:
            channel: CAN channel
            bitrate: Bitrate
            backend: Backend type
        
        Returns:
            CAN bus instance
        
        Raises:
            CanBusError: If cannot create bus
        """
        # Validate channel first (CAN-004)
        is_valid, error_msg = validate_can_channel(channel, backend)
        if not is_valid:
            raise CanConfigurationError(f"Invalid CAN channel: {error_msg}")
        
        key = self._get_key(channel, bitrate, backend)
        
        with self._lock:
            # Check if we have an available bus
            if key in self._pool:
                bus, last_used = self._pool[key]
                # Verify bus is still alive
                if self._validate_bus(bus):
                    self._usage_count[key] = self._usage_count.get(key, 0) + 1
                    self._pool[key] = (bus, time.time())  # Update last used
                    _log_debug(f"Acquired existing CAN bus: {key}")
                    return bus
                else:
                    # Remove dead bus
                    _log_warn(f"Removing dead CAN bus from pool: {key}")
                    del self._pool[key]
            
            # Create new bus
            bus = self._create_bus(channel, bitrate, backend)
            self._pool[key] = (bus, time.time())
            self._usage_count[key] = 1
            _log_info(f"Created new CAN bus: {key}")
            return bus
    
    def release(self, bus: Bus):
        """Release a bus back to the pool."""
        # Find the key for this bus
        for key, (pool_bus, _) in list(self._pool.items()):
            if pool_bus == bus:
                with self._lock:
                    self._usage_count[key] = max(0, self._usage_count.get(key, 1) - 1)
                    _log_debug(f"Released CAN bus: {key}, remaining usage: {self._usage_count[key]}")
                return
        
        _log_warn("Attempted to release unknown CAN bus")
    
    def _validate_bus(self, bus: Bus) -> bool:
        """Check if bus is still alive."""
        try:
            # Check if bus has required attributes
            if not hasattr(bus, 'send') or not hasattr(bus, 'recv'):
                return False
            
            # Check bus state if supported
            if hasattr(bus, 'state'):
                try:
                    # Some backends have state attribute
                    if bus.state.name == 'ERROR':
                        _log_warn("CAN bus is in ERROR state")
                        return False
                except:
                    pass
            
            # Try to send a minimal message (if bus supports loopback)
            # This is a lightweight check that won't affect the bus
            return True
            
        except Exception as e:
            _log_debug(f"Bus validation failed: {e}")
            return False
    
    def _create_bus(self, channel: str, bitrate: int, backend: str) -> Bus:
        """Create a new bus instance."""
        backend = backend.strip().lower()
        
        try:
            if backend == "pcan":
                return interface.Bus(
                    channel=channel,
                    bustype="pcan",
                    bitrate=bitrate,
                )
            elif backend == "socketcan":
                return interface.Bus(
                    channel=channel,
                    bustype="socketcan",
                    bitrate=bitrate,
                )
            else:
                raise ValueError(f"Unsupported CAN backend: {backend}")
        except Exception as e:
            raise CanBusError(f"Failed to create CAN bus: {e}") from e
    
    def _cleanup_loop(self):
        """Background thread to clean up idle connections."""
        while True:
            time.sleep(60)  # Check every minute
            self._cleanup_idle()
    
    def _cleanup_idle(self):
        """Remove idle connections."""
        now = time.time()
        removed = 0
        
        with self._lock:
            for key, (bus, last_used) in list(self._pool.items()):
                if self._usage_count.get(key, 0) == 0:
                    if now - last_used > self.idle_timeout:
                        try:
                            bus.shutdown()
                            _log_info(f"Closed idle CAN connection: {key}")
                        except Exception as e:
                            _log_warn(f"Error closing idle CAN bus {key}: {e}")
                        finally:
                            del self._pool[key]
                            self._usage_count.pop(key, None)
                            removed += 1
        
        if removed > 0:
            _log_debug(f"Cleaned up {removed} idle CAN connections")
    
    def close_all(self):
        """Close all connections."""
        with self._lock:
            for key, (bus, _) in list(self._pool.items()):
                try:
                    bus.shutdown()
                    _log_info(f"Closed CAN connection: {key}")
                except Exception as e:
                    _log_warn(f"Error closing CAN bus {key}: {e}")
            self._pool.clear()
            self._usage_count.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get pool statistics."""
        with self._lock:
            return {
                "total_connections": len(self._pool),
                "active_connections": sum(1 for k in self._pool if self._usage_count.get(k, 0) > 0),
                "max_size": self.max_size,
                "idle_timeout": self.idle_timeout,
                "connections": [
                    {
                        "key": k,
                        "usage_count": self._usage_count.get(k, 0),
                        "idle_seconds": time.time() - last_used if self._usage_count.get(k, 0) == 0 else 0
                    }
                    for k, (_, last_used) in self._pool.items()
                ]
            }


# Global pool instance
_can_pool = CanBusPool(
    max_size=int(os.getenv("CAN_POOL_SIZE", "5")),
    idle_timeout=int(os.getenv("CAN_IDLE_TIMEOUT", "300"))
)


# =============================================================================
# CAN BUS MANAGEMENT (CAN-001, CAN-003)
# =============================================================================

def open_can_bus(
    *,
    channel: Optional[str] = None,
    bitrate: Optional[int] = None,
    backend: Optional[str] = None,
) -> Bus:
    """
    Open CAN bus safely using connection pool.

    If parameters are omitted, values are resolved from DB (app.config).

    Args:
        channel: CAN channel (e.g., 'PCAN_USBBUS1', 'can0')
        bitrate: Bitrate in bps
        backend: Backend type ('pcan' or 'socketcan')

    Returns:
        CAN bus instance

    Raises:
        CanConfigurationError: If configuration is invalid
        CanBusError: If bus cannot be opened
    """
    cfg = get_can_config()

    channel = (channel or cfg["channel"] or "").strip()
    bitrate = bitrate if bitrate is not None else cfg["bitrate"]
    backend = (backend or cfg["backend"] or "pcan").strip().lower()

    if not channel:
        raise CanConfigurationError("CAN channel is required")
    
    # CAN-004: Validate channel format
    is_valid, error_msg = validate_can_channel(channel, backend)
    if not is_valid:
        raise CanConfigurationError(f"Invalid CAN channel: {error_msg}")

    return _can_pool.acquire(channel, bitrate, backend)


def close_can_bus(bus: Optional[Bus]) -> None:
    """
    Release CAN bus back to pool.
    
    Args:
        bus: CAN bus instance to release
    """
    if bus:
        _can_pool.release(bus)


def close_all_can_buses():
    """Close all CAN buses (for shutdown)."""
    _can_pool.close_all()
    _log_info("All CAN buses closed")


# =============================================================================
# BUS VALIDATION (CAN-001)
# =============================================================================

def validate_bus(bus: Optional[Bus]) -> bool:
    """
    Validate that bus is connected and operational.
    
    Args:
        bus: CAN bus instance
    
    Returns:
        True if bus is valid, False otherwise
    """
    if bus is None:
        _log_warn("Bus validation failed: bus is None")
        return False
    
    # Check if bus has required attributes
    if not hasattr(bus, 'send') or not hasattr(bus, 'recv'):
        _log_warn("Bus validation failed: missing required attributes")
        return False
    
    # Check bus state if supported
    if hasattr(bus, 'state'):
        try:
            # Some backends have state attribute
            if hasattr(bus.state, 'name') and bus.state.name == 'ERROR':
                _log_warn("Bus validation failed: bus in ERROR state")
                return False
        except:
            pass
    
    return True


# =============================================================================
# GENERIC DIAGNOSTIC HELPERS (CAN-001, CAN-005)
# =============================================================================

def send_can_frame(
    bus: Bus,
    arbitration_id: int,
    data: bytes,
    *,
    is_extended_id: bool = False,
    timeout: float = 1.0,
    validate: bool = True
) -> None:
    """
    Send one CAN frame with validation and timeout.
    
    Args:
        bus: CAN bus instance
        arbitration_id: CAN ID
        data: Data bytes
        is_extended_id: Whether to use extended ID
        timeout: Send timeout in seconds
        validate: Whether to validate bus before sending
    
    Raises:
        CanBusError: If bus is invalid or send fails
        CanTimeoutError: If send times out
    """
    # CAN-001: Validate bus
    if validate and not validate_bus(bus):
        raise CanBusError("CAN bus is not connected or in error state")
    
    from can import Message
    
    msg = Message(
        arbitration_id=arbitration_id,
        data=data,
        is_extended_id=is_extended_id
    )
    
    try:
        # CAN-005: Use timeout
        bus.send(msg, timeout=timeout)
        _log_debug(f"Sent CAN frame: ID={arbitration_id:03X}, data={data.hex()}")
    except can.CanError as e:
        raise CanBusError(f"Failed to send CAN frame: {e}") from e
    except Exception as e:
        raise CanError(f"Unexpected error sending CAN frame: {e}") from e


def recv_can_frame(
    bus: Bus,
    timeout: float = 1.0,
    validate: bool = True
) -> Optional[Message]:
    """
    Receive one CAN frame with validation.
    
    Args:
        bus: CAN bus instance
        timeout: Receive timeout in seconds
        validate: Whether to validate bus before receiving
    
    Returns:
        CAN message or None on timeout
    
    Raises:
        CanBusError: If bus is invalid
        CanError: If receive fails
    """
    # CAN-001: Validate bus
    if validate and not validate_bus(bus):
        raise CanBusError("CAN bus is not connected or in error state")
    
    try:
        msg = bus.recv(timeout)
        if msg:
            _log_debug(f"Received CAN frame: ID={msg.arbitration_id:03X}, data={msg.data.hex()}")
        return msg
    except can.CanError as e:
        raise CanBusError(f"Failed to receive CAN frame: {e}") from e
    except Exception as e:
        raise CanError(f"Unexpected error receiving CAN frame: {e}") from e


def send_can_frame_with_retry(
    bus: Bus,
    arbitration_id: int,
    data: bytes,
    *,
    is_extended_id: bool = False,
    timeout: float = 1.0,
    max_retries: int = 3,
    retry_delay: float = 0.1
) -> bool:
    """
    Send CAN frame with retry logic.
    
    Args:
        bus: CAN bus instance
        arbitration_id: CAN ID
        data: Data bytes
        is_extended_id: Whether to use extended ID
        timeout: Send timeout per attempt
        max_retries: Maximum number of retries
        retry_delay: Delay between retries
    
    Returns:
        True if successful, False after all retries fail
    """
    for attempt in range(max_retries):
        try:
            send_can_frame(bus, arbitration_id, data, is_extended_id=is_extended_id, timeout=timeout)
            return True
        except (CanBusError, CanTimeoutError) as e:
            if attempt == max_retries - 1:
                _log_error(f"Failed to send CAN frame after {max_retries} attempts: {e}")
                return False
            _log_warn(f"Send attempt {attempt + 1} failed, retrying in {retry_delay}s: {e}")
            time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
    
    return False


# =============================================================================
# CONTEXT MANAGER (RECOMMENDED USAGE)
# =============================================================================

class CanSession:
    """
    Context manager for CAN session handling.

    Usage:
        with CanSession() as bus:
            ...
    """

    def __init__(
        self,
        *,
        channel: Optional[str] = None,
        bitrate: Optional[int] = None,
        backend: Optional[str] = None,
    ):
        self._params = {"channel": channel, "bitrate": bitrate, "backend": backend}
        self.bus: Optional[Bus] = None

    def __enter__(self) -> Bus:
        self.bus = open_can_bus(**self._params)
        return self.bus

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self.bus:
            close_can_bus(self.bus)
            self.bus = None


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def get_can_stats() -> Dict[str, Any]:
    """Get CAN bus statistics."""
    return {
        "pool": _can_pool.get_stats(),
        "config": get_can_config()
    }


def test_can_connection(
    channel: Optional[str] = None,
    bitrate: Optional[int] = None,
    backend: Optional[str] = None,
    timeout: float = 1.0
) -> Tuple[bool, str]:
    """
    Test CAN bus connection.
    
    Args:
        channel: CAN channel
        bitrate: Bitrate
        backend: Backend type
        timeout: Test timeout
    
    Returns:
        Tuple of (success, message)
    """
    try:
        with CanSession(channel=channel, bitrate=bitrate, backend=backend) as bus:
            # Try to send a minimal message (if bus supports loopback)
            # This just tests that the bus is open and responsive
            test_msg = Message(arbitration_id=0x7DF, data=[0x00] * 8)
            bus.send(test_msg, timeout=timeout)
            return True, "CAN bus connection successful"
    except Exception as e:
        return False, f"CAN bus test failed: {e}"


# =============================================================================
# MODULE INITIALIZATION
# =============================================================================

def _init():
    """Initialize CAN utilities module."""
    _log_info(f"CAN Utilities v2.1.0 initialized")
    _log_info(f"CAN pool: max_size={_can_pool.max_size}, idle_timeout={_can_pool.idle_timeout}")
    
    # Test configuration
    try:
        cfg = get_can_config()
        _log_info(f"Default CAN config: {cfg}")
    except Exception as e:
        _log_warn(f"Could not load default CAN config: {e}")


_init()


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Configuration
    "get_config_value",
    "set_config_value",
    "get_can_config",
    
    # Bus management
    "open_can_bus",
    "close_can_bus",
    "close_all_can_buses",
    "CanSession",
    
    # Frame I/O
    "send_can_frame",
    "recv_can_frame",
    "send_can_frame_with_retry",
    
    # Validation
    "validate_bus",
    "validate_can_channel",
    "test_can_connection",
    
    # Statistics
    "get_can_stats",
    
    # Exceptions
    "CanError",
    "CanTimeoutError",
    "CanBusError",
    "CanConfigurationError",
]