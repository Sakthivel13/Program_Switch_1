-- =============================================================================
-- NIRIX Diagnostic System - ALTER TABLES SCRIPT
-- This script modifies existing tables to add all fixes and improvements
-- WITHOUT dropping or recreating tables
-- =============================================================================

-- Start transaction
BEGIN;

-- =============================================================================
-- SECTION 1: USERS TABLE ENHANCEMENTS
-- =============================================================================

-- Add account lockout columns (SEC-011)
ALTER TABLE app.users 
ADD COLUMN IF NOT EXISTS failed_attempts INT DEFAULT 0;

ALTER TABLE app.users 
ADD COLUMN IF NOT EXISTS locked_until TIMESTAMP;

-- Add secure password reset columns (SEC-012)
ALTER TABLE app.users 
ADD COLUMN IF NOT EXISTS reset_token VARCHAR(64);

ALTER TABLE app.users 
ADD COLUMN IF NOT EXISTS reset_token_expires TIMESTAMP;

-- Migrate existing reset_code data if any (SEC-012)
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_schema = 'app' AND table_name = 'users' AND column_name = 'reset_code') THEN
        UPDATE app.users 
        SET reset_token = reset_code, 
            reset_token_expires = CURRENT_TIMESTAMP + INTERVAL '1 day'
        WHERE reset_code IS NOT NULL;
        
        ALTER TABLE app.users DROP COLUMN reset_code;
    END IF;
END $$;

-- Add theme constraint if not exists
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'chk_users_theme' AND table_schema = 'app') THEN
        ALTER TABLE app.users 
        ADD CONSTRAINT chk_users_theme CHECK (theme IN ('light', 'dark'));
    END IF;
END $$;

-- Create indexes for new columns
CREATE INDEX IF NOT EXISTS idx_users_locked ON app.users(locked_until) WHERE locked_until IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_reset_token ON app.users(reset_token) WHERE reset_token IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_reset_expires ON app.users(reset_token_expires) WHERE reset_token_expires IS NOT NULL;

-- =============================================================================
-- SECTION 2: VEHICLES TABLE ENHANCEMENTS
-- =============================================================================

-- Add VIN pattern constraint (DAT-002)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'chk_vehicles_vin_pattern' AND table_schema = 'app') THEN
        ALTER TABLE app.vehicles 
        ADD CONSTRAINT chk_vehicles_vin_pattern CHECK (
            vin_pattern IS NULL OR 
            vin_pattern ~ '^[A-HJ-NPR-Z0-9\*\?\[\]_-]+$'
        );
    END IF;
END $$;

-- =============================================================================
-- SECTION 3: LOGS TABLE ENHANCEMENTS
-- =============================================================================

-- Add VIN format constraint (DAT-002)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'chk_logs_vin_format' AND table_schema = 'app') THEN
        ALTER TABLE app.logs 
        ADD CONSTRAINT chk_logs_vin_format CHECK (
            vin IS NULL OR vin ~ '^[A-HJ-NPR-Z0-9]{17}$'
        );
    END IF;
END $$;

-- Add VIN source column if not exists
ALTER TABLE app.logs 
ADD COLUMN IF NOT EXISTS vin_source VARCHAR(20);

-- Add VIN source constraint
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'chk_logs_vin_source' AND table_schema = 'app') THEN
        ALTER TABLE app.logs 
        ADD CONSTRAINT chk_logs_vin_source CHECK (
            vin_source IS NULL OR vin_source IN ('auto', 'manual', 'none')
        );
    END IF;
END $$;

-- Add vehicle_id foreign key if not exists (DAT-006)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints 
                   WHERE constraint_name = 'logs_vehicle_id_fkey' AND table_schema = 'app') THEN
        -- Add vehicle_id column if not exists
        ALTER TABLE app.logs ADD COLUMN IF NOT EXISTS vehicle_id BIGINT;
        
        -- Update vehicle_id based on vehicle_name
        UPDATE app.logs l
        SET vehicle_id = v.id
        FROM app.vehicles v
        WHERE l.vehicle_name = v.name AND l.vehicle_id IS NULL;
        
        -- Add foreign key constraint
        ALTER TABLE app.logs 
        ADD CONSTRAINT logs_vehicle_id_fkey 
        FOREIGN KEY (vehicle_id) REFERENCES app.vehicles(id) ON DELETE SET NULL;
    END IF;
END $$;

-- Create composite index for common queries (PERF-002)
CREATE INDEX IF NOT EXISTS idx_logs_vehicle_vin_created 
ON app.logs(vehicle_name, vin, created_at DESC);

-- =============================================================================
-- SECTION 4: AUTO_RUN_SESSIONS TABLE ENHANCEMENTS
-- =============================================================================

-- Add VIN format constraint (DAT-002)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'chk_auto_run_sessions_vin' AND table_schema = 'app') THEN
        ALTER TABLE app.auto_run_sessions 
        ADD CONSTRAINT chk_auto_run_sessions_vin CHECK (
            vin IS NULL OR vin ~ '^[A-HJ-NPR-Z0-9]{17}$'
        );
    END IF;
END $$;

-- Add status constraint if not exists
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'auto_run_sessions_status_check' AND table_schema = 'app') THEN
        ALTER TABLE app.auto_run_sessions 
        ADD CONSTRAINT auto_run_sessions_status_check 
        CHECK (status IN ('started', 'running', 'completed', 'stopped', 'failed', 'expired'));
    END IF;
END $$;

-- Add vin_source constraint
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'auto_run_sessions_vin_source_check' AND table_schema = 'app') THEN
        ALTER TABLE app.auto_run_sessions 
        ADD CONSTRAINT auto_run_sessions_vin_source_check 
        CHECK (vin_source IN ('none', 'auto', 'manual'));
    END IF;
END $$;

-- Add cleanup_at column for session cleanup (SRV-005)
ALTER TABLE app.auto_run_sessions 
ADD COLUMN IF NOT EXISTS cleanup_at TIMESTAMP;

-- Add indexes for cleanup operations (PERF-001)
CREATE INDEX IF NOT EXISTS idx_auto_run_sessions_cleanup 
ON app.auto_run_sessions(last_accessed) WHERE status IN ('running', 'started');

CREATE INDEX IF NOT EXISTS idx_auto_run_sessions_updated 
ON app.auto_run_sessions(updated_at);

-- =============================================================================
-- SECTION 5: AUTO_RUN_RESULTS TABLE ENHANCEMENTS
-- =============================================================================

-- Drop existing foreign key if exists and recreate with CASCADE (DAT-001)
DO $$
BEGIN
    -- Drop existing foreign key if it exists without CASCADE
    IF EXISTS (SELECT 1 FROM information_schema.table_constraints 
               WHERE constraint_name = 'auto_run_results_session_id_fkey' 
               AND table_schema = 'app') THEN
        
        -- Check if it already has CASCADE
        IF NOT EXISTS (SELECT 1 FROM information_schema.referential_constraints 
                       WHERE constraint_name = 'auto_run_results_session_id_fkey' 
                       AND delete_rule = 'CASCADE') THEN
            ALTER TABLE app.auto_run_results 
            DROP CONSTRAINT auto_run_results_session_id_fkey;
            
            ALTER TABLE app.auto_run_results 
            ADD CONSTRAINT auto_run_results_session_id_fkey 
            FOREIGN KEY (session_id) REFERENCES app.auto_run_sessions(session_id) ON DELETE CASCADE;
        END IF;
    END IF;
END $$;

-- Add program_type constraint
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'auto_run_results_type_check' AND table_schema = 'app') THEN
        ALTER TABLE app.auto_run_results 
        ADD CONSTRAINT auto_run_results_type_check 
        CHECK (program_type IN ('single', 'stream'));
    END IF;
END $$;

-- Add status constraint
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'auto_run_results_status_check' AND table_schema = 'app') THEN
        ALTER TABLE app.auto_run_results 
        ADD CONSTRAINT auto_run_results_status_check 
        CHECK (status IN ('pending', 'running', 'success', 'failed', 'manual', 'skipped'));
    END IF;
END $$;

-- Add source column if not exists
ALTER TABLE app.auto_run_results 
ADD COLUMN IF NOT EXISTS source TEXT DEFAULT 'section';

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_auto_run_results_source ON app.auto_run_results(source);

-- =============================================================================
-- SECTION 6: AUTO_RUN_STREAM_VALUES TABLE ENHANCEMENTS
-- =============================================================================

-- Drop existing foreign key if exists and recreate with CASCADE (DAT-001)
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.table_constraints 
               WHERE constraint_name = 'auto_run_stream_values_session_id_fkey' 
               AND table_schema = 'app') THEN
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.referential_constraints 
                       WHERE constraint_name = 'auto_run_stream_values_session_id_fkey' 
                       AND delete_rule = 'CASCADE') THEN
            ALTER TABLE app.auto_run_stream_values 
            DROP CONSTRAINT auto_run_stream_values_session_id_fkey;
            
            ALTER TABLE app.auto_run_stream_values 
            ADD CONSTRAINT auto_run_stream_values_session_id_fkey 
            FOREIGN KEY (session_id) REFERENCES app.auto_run_sessions(session_id) ON DELETE CASCADE;
        END IF;
    END IF;
END $$;

-- Drop redundant indexes (PERF-001)
DROP INDEX IF EXISTS app.idx_stream_values_session;
DROP INDEX IF EXISTS app.idx_auto_run_stream_values_session;

-- Ensure unique constraint exists (FIX-64)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints 
                   WHERE constraint_name = 'uq_auto_run_stream_values_session_signal' 
                   AND table_schema = 'app') THEN
        ALTER TABLE app.auto_run_stream_values 
        ADD CONSTRAINT uq_auto_run_stream_values_session_signal UNIQUE (session_id, signal_name);
    END IF;
END $$;

-- Create index for cleanup
CREATE INDEX IF NOT EXISTS idx_auto_run_stream_values_updated ON app.auto_run_stream_values(updated_at);

-- =============================================================================
-- SECTION 7: ECU_ACTIVE_STATUS TABLE ENHANCEMENTS
-- =============================================================================

-- Drop existing foreign key if exists and recreate with CASCADE (DAT-001)
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.table_constraints 
               WHERE constraint_name = 'ecu_active_status_session_id_fkey' 
               AND table_schema = 'app') THEN
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.referential_constraints 
                       WHERE constraint_name = 'ecu_active_status_session_id_fkey' 
                       AND delete_rule = 'CASCADE') THEN
            ALTER TABLE app.ecu_active_status 
            DROP CONSTRAINT ecu_active_status_session_id_fkey;
            
            ALTER TABLE app.ecu_active_status 
            ADD CONSTRAINT ecu_active_status_session_id_fkey 
            FOREIGN KEY (session_id) REFERENCES app.auto_run_sessions(session_id) ON DELETE CASCADE;
        END IF;
    END IF;
END $$;

-- Drop redundant indexes (PERF-001)
DROP INDEX IF EXISTS app.idx_ecu_status_session;
DROP INDEX IF EXISTS app.idx_ecu_active_status_session;
DROP INDEX IF EXISTS app.idx_ecu_active_status_cleanup;

-- Ensure unique constraint exists
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints 
                   WHERE constraint_name = 'uq_ecu_active_status_session_ecu' 
                   AND table_schema = 'app') THEN
        ALTER TABLE app.ecu_active_status 
        ADD CONSTRAINT uq_ecu_active_status_session_ecu UNIQUE (session_id, ecu_code);
    END IF;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_ecu_active_status_ecu ON app.ecu_active_status(ecu_code);
CREATE INDEX IF NOT EXISTS idx_ecu_active_status_cleanup ON app.ecu_active_status(updated_at);

-- =============================================================================
-- SECTION 8: TEST_OUTPUT_LIMITS TABLE ENHANCEMENTS
-- =============================================================================

-- Add LSL ≤ USL constraint (CFG-003)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'chk_test_output_limits_lsl_le_usl' 
                   AND table_schema = 'app') THEN
        ALTER TABLE app.test_output_limits 
        ADD CONSTRAINT chk_test_output_limits_lsl_le_usl CHECK (
            lsl IS NULL OR usl IS NULL OR lsl <= usl
        );
    END IF;
END $$;

-- =============================================================================
-- SECTION 9: TEST_INPUTS TABLE ENHANCEMENTS
-- =============================================================================

-- Add config_key constraint
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'chk_test_inputs_config_key' 
                   AND table_schema = 'app') THEN
        ALTER TABLE app.test_inputs 
        ADD CONSTRAINT chk_test_inputs_config_key CHECK (
            config_key IS NULL OR config_key ~ '^[a-zA-Z0-9_.-]+$'
        );
    END IF;
END $$;

-- Add foreign key from config_key to config table (DAT-010)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints 
                   WHERE constraint_name = 'test_inputs_config_key_fkey' 
                   AND table_schema = 'app') THEN
        ALTER TABLE app.test_inputs 
        ADD CONSTRAINT test_inputs_config_key_fkey 
        FOREIGN KEY (config_key) REFERENCES app.config(key_name) ON DELETE SET NULL;
    END IF;
END $$;

-- =============================================================================
-- SECTION 10: TEST_EXECUTION_RESULTS TABLE ENHANCEMENTS
-- =============================================================================

-- Add duration constraint
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'test_execution_results_duration_positive' 
                   AND table_schema = 'app') THEN
        ALTER TABLE app.test_execution_results 
        ADD CONSTRAINT test_execution_results_duration_positive CHECK (
            duration_ms IS NULL OR duration_ms >= 0
        );
    END IF;
END $$;

-- Add attempts constraint
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage 
                   WHERE constraint_name = 'test_execution_results_attempts_positive' 
                   AND table_schema = 'app') THEN
        ALTER TABLE app.test_execution_results 
        ADD CONSTRAINT test_execution_results_attempts_positive CHECK (
            attempts IS NULL OR attempts > 0
        );
    END IF;
END $$;

-- =============================================================================
-- SECTION 11: VEHICLE_DIAGNOSTIC_ACTIONS TABLE ENHANCEMENTS
-- =============================================================================

-- Add GIN index for auto_run_programs JSONB (PERF-002)
CREATE INDEX IF NOT EXISTS idx_vehicle_diagnostic_actions_auto_run_gin 
ON app.vehicle_diagnostic_actions USING gin(auto_run_programs);

-- =============================================================================
-- SECTION 12: CONFIG TABLE ENHANCEMENTS
-- =============================================================================

-- Ensure unique constraint exists
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints 
                   WHERE constraint_name = 'uq_config_key' AND table_schema = 'app') THEN
        ALTER TABLE app.config 
        ADD CONSTRAINT uq_config_key UNIQUE (key_name);
    END IF;
END $$;

-- =============================================================================
-- SECTION 13: AUTO_RUN_VIN_LOG TABLE (CREATE IF NOT EXISTS)
-- =============================================================================

CREATE TABLE IF NOT EXISTS app.auto_run_vin_log (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL REFERENCES app.auto_run_sessions(session_id) ON DELETE CASCADE,
    program_id VARCHAR(100) NOT NULL,
    vin VARCHAR(17) NOT NULL,
    source VARCHAR(20) NOT NULL CHECK (source IN ('auto', 'manual')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_auto_run_vin_log_vin CHECK (vin ~ '^[A-HJ-NPR-Z0-9]{17}$')
);

CREATE INDEX IF NOT EXISTS idx_auto_run_vin_log_session ON app.auto_run_vin_log(session_id);

-- =============================================================================
-- SECTION 14: USER_LOGIN_SESSIONS TABLE (CREATE IF NOT EXISTS)
-- =============================================================================

CREATE TABLE IF NOT EXISTS app.user_login_sessions (
    id SERIAL PRIMARY KEY,
    user_id INT NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    login_id UUID NOT NULL,
    ip_address INET,
    user_agent TEXT,
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    
    CONSTRAINT uq_user_login_sessions_user_login UNIQUE (user_id, login_id)
);

CREATE INDEX IF NOT EXISTS idx_user_login_sessions_user ON app.user_login_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_login_sessions_active ON app.user_login_sessions(is_active) WHERE is_active = TRUE;

-- =============================================================================
-- SECTION 15: AUDIT_LOG TABLE (CREATE IF NOT EXISTS)
-- =============================================================================

CREATE TABLE IF NOT EXISTS app.audit_log (
    id BIGSERIAL PRIMARY KEY,
    user_id INT REFERENCES app.users(id) ON DELETE SET NULL,
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id VARCHAR(100),
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audit_log_user ON app.audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON app.audit_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_created ON app.audit_log(created_at);

-- =============================================================================
-- SECTION 16: FUNCTIONS AND TRIGGERS
-- =============================================================================

-- Create update_updated_at_column function if not exists
CREATE OR REPLACE FUNCTION app.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for tables with updated_at
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.triggers 
                   WHERE trigger_name = 'trigger_update_users_updated_at' 
                   AND event_object_schema = 'app') THEN
        CREATE TRIGGER trigger_update_users_updated_at 
        BEFORE UPDATE ON app.users
        FOR EACH ROW EXECUTE FUNCTION app.update_updated_at_column();
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.triggers 
                   WHERE trigger_name = 'trigger_update_vehicles_updated_at' 
                   AND event_object_schema = 'app') THEN
        CREATE TRIGGER trigger_update_vehicles_updated_at 
        BEFORE UPDATE ON app.vehicles
        FOR EACH ROW EXECUTE FUNCTION app.update_updated_at_column();
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.triggers 
                   WHERE trigger_name = 'trigger_update_tests_updated_at' 
                   AND event_object_schema = 'app') THEN
        CREATE TRIGGER trigger_update_tests_updated_at 
        BEFORE UPDATE ON app.tests
        FOR EACH ROW EXECUTE FUNCTION app.update_updated_at_column();
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.triggers 
                   WHERE trigger_name = 'trigger_update_auto_run_sessions_updated_at' 
                   AND event_object_schema = 'app') THEN
        CREATE TRIGGER trigger_update_auto_run_sessions_updated_at 
        BEFORE UPDATE ON app.auto_run_sessions
        FOR EACH ROW EXECUTE FUNCTION app.update_updated_at_column();
    END IF;
END $$;

-- Create cleanup_expired_sessions function
CREATE OR REPLACE FUNCTION app.cleanup_expired_sessions()
RETURNS INT AS $$
DECLARE
    cleaned_count INT;
BEGIN
    -- Mark expired auto-run sessions
    UPDATE app.auto_run_sessions
    SET status = 'expired', 
        ended_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE status IN ('running', 'started')
      AND last_accessed < NOW() - INTERVAL '2 hours'
    RETURNING COUNT(*) INTO cleaned_count;
    
    -- Clean up old stream values
    DELETE FROM app.auto_run_stream_values
    WHERE updated_at < NOW() - INTERVAL '1 hour';
    
    -- Clean up old ECU status
    DELETE FROM app.ecu_active_status
    WHERE updated_at < NOW() - INTERVAL '1 hour';
    
    -- Deactivate stale login sessions
    UPDATE app.user_login_sessions
    SET is_active = FALSE
    WHERE is_active = TRUE
      AND last_activity < NOW() - INTERVAL '24 hours';
    
    RETURN cleaned_count;
END;
$$ LANGUAGE plpgsql;

-- =============================================================================
-- SECTION 17: ADD COMMENTS FOR DOCUMENTATION
-- =============================================================================

COMMENT ON COLUMN app.auto_run_sessions.vin IS 'Vehicle Identification Number (17 chars, no I/O/Q)';
COMMENT ON COLUMN app.auto_run_sessions.vin_source IS 'Source of VIN: none, auto, manual';

COMMENT ON COLUMN app.auto_run_results.result_data IS 'JSON structure varies by program type:
- Single tests: {"value": any}
- Stream tests: {"battery_voltage": number, ...}
- DTC tests: {"dtcs": [{"code": string, "status": string}]}
- ECU status: {"is_active": boolean, "ecu_code": string}';

COMMENT ON COLUMN app.vehicle_diagnostic_actions.auto_run_programs IS 'Array of auto-run program objects with structure:
{
  "program_id": string,
  "program_name": string,
  "program_type": "single"|"stream",
  "module_name": string,
  "function_name": string,
  "execution_mode": "single"|"stream"|"flashing",
  "display_type": "text"|"value"|"status"|"json",
  "display_label": string,
  "display_unit": string|null,
  "display_pages": ["section","ecu","parameter"],
  "ecu_targets": string[],
  "output_limits": [{"signal": string, "lsl": number, "usl": number, "unit": string}],
  "fallback_action": "none"|"manual_input"|"warn_and_continue"|"block",
  "log_as_vin": boolean,
  "is_required": boolean,
  "timeout_sec": number,
  "sort_order": integer
}';

-- =============================================================================
-- SECTION 18: DATA MIGRATIONS
-- =============================================================================

-- Migrate existing VIN data to uppercase
UPDATE app.logs SET vin = UPPER(vin) WHERE vin IS NOT NULL;
UPDATE app.auto_run_sessions SET vin = UPPER(vin) WHERE vin IS NOT NULL;

-- Set default vin_source for existing records
UPDATE app.logs SET vin_source = 'auto' WHERE vin IS NOT NULL AND vin_source IS NULL;
UPDATE app.auto_run_sessions SET vin_source = 'auto' WHERE vin IS NOT NULL AND vin_source IS NULL;

-- Commit all changes
COMMIT;

-- =============================================================================
-- VERIFICATION QUERIES
-- =============================================================================

/*
-- Run these queries to verify all changes were applied successfully

-- Check new columns in users table
SELECT column_name, data_type, is_nullable 
FROM information_schema.columns 
WHERE table_schema = 'app' AND table_name = 'users' 
AND column_name IN ('failed_attempts', 'locked_until', 'reset_token', 'reset_token_expires');

-- Check foreign keys with CASCADE
SELECT conname, confdeltype 
FROM pg_constraint 
WHERE conname IN ('auto_run_results_session_id_fkey', 'auto_run_stream_values_session_id_fkey', 'ecu_active_status_session_id_fkey');

-- Check new indexes
SELECT indexname FROM pg_indexes WHERE schemaname = 'app' AND indexname LIKE 'idx_%';

-- Check CHECK constraints
SELECT conname, consrc 
FROM pg_constraint 
WHERE contype = 'c' AND connamespace = 'app'::regnamespace;
*/