ecu_active_check,

# -*- coding: utf-8 -*-
"""
AUTO_ECU_ACTIVE_CHECK (single)

- Returns ecus_ok (1/0) so runner output_limits can fail the program
- Returns ecu_statuses list so service can persist to app.ecu_active_status
- Does NOT raise RuntimeError just because ECU is inactive (so output is preserved)

Version: 2.1.0
Last Updated: 2026-02-23

FIXES:
- AR-PERSIST-002: Fixed ECU status persistence with proper format
- PROTO-009: Added timeout handling for multiple ECUs with retries
- CAN-001: Added bus validation
- PROTO-006: Added 29-bit CAN ID support
- DAT-008: Added proper error tracking
"""

from __future__ import annotations

import time
import logging
from typing import Dict, Any, Optional, List, Tuple

import can

# =============================================================================
# CONSTANTS
# =============================================================================

DEFAULT_ECUS: List[str] = ["BMS"]
DEFAULT_PER_ECU_TIMEOUT = 1.0
DEFAULT_RETRY_COUNT = 3
DEFAULT_RETRY_DELAY = 0.2

ECU_ADDRS: Dict[str, Dict[str, int]] = {
    "BMS": {"req": 0x7F0, "res": 0x7F1},
}

# =============================================================================
# LOGGING
# =============================================================================

logging.getLogger("can").setLevel(logging.ERROR)
logger = logging.getLogger(__name__)


# =============================================================================
# EXCEPTIONS
# =============================================================================

class DiagnosticNegativeResponse(Exception):
    """Exception for UDS negative responses."""
    def __init__(self, service_id: int, nrc: int, message: str = ""):
        super().__init__(f"7F {service_id:02X} {nrc:02X}: {message}")
        self.service_id = service_id
        self.nrc = nrc
        self.message = message


# =============================================================================
# BUS MANAGEMENT
# =============================================================================

def _log(context, msg: str, level: str = "INFO"):
    """Log message to context or print."""
    if context is not None:
        try:
            context.log(msg, level)
            return
        except Exception:
            pass
    getattr(logger, level.lower(), logger.info)(msg)


def _open_bus(can_interface: str, bitrate: int, is_extended: bool = False) -> can.Bus:
    """Open CAN bus with support for extended IDs."""
    iface = (can_interface or "").strip()
    if iface.upper().startswith("PCAN"):
        return can.Bus(interface="pcan", channel=iface, bitrate=int(bitrate), fd=False)
    if iface.lower().startswith("can"):
        return can.Bus(interface="socketcan", channel=iface, bitrate=int(bitrate))
    raise ValueError(f"Unsupported CAN interface: {iface}")


def _validate_bus(bus: Optional[can.Bus], context=None) -> bool:
    """Validate that bus is connected and operational."""
    if bus is None:
        _log(context, "CAN bus is None", "ERROR")
        return False
    
    try:
        if not hasattr(bus, 'send') or not hasattr(bus, 'recv'):
            return False
        
        if hasattr(bus, 'state') and hasattr(bus.state, 'name') and bus.state.name == 'ERROR':
            return False
        
        return True
    except Exception:
        return False


# =============================================================================
# UDS HELPERS
# =============================================================================

def _send_tester_present(
    bus: can.Bus, 
    req_id: int, 
    is_extended_id: bool = False,
    context=None
) -> bool:
    """Send TesterPresent (3E 00) request."""
    data = bytearray([0x02, 0x3E, 0x00, 0, 0, 0, 0, 0])
    msg = can.Message(
        arbitration_id=req_id, 
        data=data, 
        is_extended_id=is_extended_id
    )
    id_str = f"{req_id:08X}" if is_extended_id else f"{req_id:03X}"
    _log(context, f"TX {id_str} " + " ".join(f"{b:02X}" for b in msg.data))
    
    try:
        bus.send(msg)
        return True
    except can.CanError as e:
        _log(context, f"Failed to send TesterPresent: {e}", "ERROR")
        return False


def _recv_sf_payload(
    bus: can.Bus, 
    res_id: int, 
    timeout_sec: float, 
    is_extended_id: bool = False,
    context=None
) -> Optional[bytes]:
    """Receive single-frame response."""
    end = time.monotonic() + max(0.0, float(timeout_sec or 0.0))
    timeout_count = 0
    
    while True:
        if context:
            context.checkpoint()

        remaining = end - time.monotonic()
        if remaining <= 0:
            return None

        try:
            msg = bus.recv(timeout=min(0.1, remaining))
        except can.CanError as e:
            _log(context, f"Receive error: {e}", "ERROR")
            continue
            
        if msg is None:
            timeout_count += 1
            if timeout_count > 5:
                return None
            continue
            
        if msg.arbitration_id != res_id or msg.is_extended_id != is_extended_id:
            continue
        if len(msg.data) < 2:
            continue

        id_str = f"{res_id:08X}" if is_extended_id else f"{res_id:03X}"
        _log(context, f"RX {id_str} " + " ".join(f"{b:02X}" for b in msg.data))

        pci_type = (msg.data[0] & 0xF0) >> 4
        if pci_type != 0x0:  # Not a single frame
            continue

        ln = int(msg.data[0] & 0x0F)
        if ln <= 0:
            return b""
        return bytes(msg.data[1:1 + min(ln, len(msg.data) - 1)])


# =============================================================================
# MAIN FUNCTION
# =============================================================================

def check_all_ecus(
    can_interface: str,
    bitrate: int,
    *,
    ecus: Optional[List[str]] = None,
    ecu_addrs: Optional[Dict[str, Dict[str, int]]] = None,
    per_ecu_timeout_sec: float = DEFAULT_PER_ECU_TIMEOUT,
    is_extended_id: bool = False,
    context=None,
    progress=None,
    **kwargs
) -> Dict[str, Any]:
    """
    Check all ECUs for active status using TesterPresent.
    
    Args:
        can_interface: CAN interface name
        bitrate: CAN bitrate
        ecus: List of ECU codes to check
        ecu_addrs: Optional address overrides
        per_ecu_timeout_sec: Timeout per ECU
        is_extended_id: Use 29-bit extended IDs
        context: Runner context
        progress: Progress callback
        **kwargs: Additional arguments
    
    Returns:
        Dictionary with keys:
        - ecus_ok: 1 if all ECUs active, 0 otherwise
        - ecu_statuses: List of ECU status dictionaries for persistence
        - details: Detailed status per ECU
    """
    bus = None
    details: Dict[str, bool] = {}
    ecu_statuses: List[Dict[str, Any]] = []
    errors: Dict[str, str] = {}

    ecu_list = list(ecus) if ecus else list(DEFAULT_ECUS)
    addr_map = dict(ECU_ADDRS)
    if ecu_addrs:
        addr_map.update(ecu_addrs)

    def _progress(p: int, m: str = ""):
        if progress:
            try: progress(int(p), str(m))
            except Exception: pass
        if context:
            try: context.progress(int(p), str(m))
            except Exception: pass

    try:
        _progress(5, f"Opening CAN ({can_interface}@{bitrate})")
        bus = _open_bus(can_interface, int(bitrate), is_extended_id)

        # CAN-001: Validate bus
        if not _validate_bus(bus, context):
            error_msg = "CAN bus validation failed"
            _log(context, error_msg, "ERROR")
            return {
                "ecus_ok": 0,
                "ecu_statuses": [{
                    "ecu_code": ecu,
                    "is_active": False,
                    "error_count": 1,
                    "error": error_msg
                } for ecu in ecu_list],
                "details": {ecu: False for ecu in ecu_list},
                "errors": {ecu: error_msg for ecu in ecu_list}
            }

        total = max(1, len(ecu_list))
        for idx, ecu_code in enumerate(ecu_list, start=1):
            addr = addr_map.get(ecu_code)
            if not addr:
                details[ecu_code] = False
                errors[ecu_code] = "No address mapping"
                ecu_statuses.append({
                    "ecu_code": ecu_code,
                    "is_active": False,
                    "error_count": 1,
                    "last_response": None,
                    "error": "No address mapping"
                })
                continue

            req_id = int(addr["req"])
            res_id = int(addr["res"])

            _progress(int(10 + (idx * 80) / total), f"ECU {ecu_code}: Checking...")

            # PROTO-009: Try with retries
            active = False
            error_msg = None
            
            for attempt in range(DEFAULT_RETRY_COUNT):
                if context:
                    context.checkpoint()
                
                if not _send_tester_present(bus, req_id, is_extended_id, context):
                    if attempt < DEFAULT_RETRY_COUNT - 1:
                        _log(context, f"Send failed, retrying ({attempt + 1}/{DEFAULT_RETRY_COUNT})", "WARN")
                        time.sleep(DEFAULT_RETRY_DELAY * (2 ** attempt))
                        continue
                    error_msg = "Failed to send TesterPresent"
                    break

                payload = _recv_sf_payload(bus, res_id, per_ecu_timeout_sec, is_extended_id, context)

                if payload is None:
                    if attempt < DEFAULT_RETRY_COUNT - 1:
                        _log(context, f"No response, retrying ({attempt + 1}/{DEFAULT_RETRY_COUNT})", "WARN")
                        time.sleep(DEFAULT_RETRY_DELAY * (2 ** attempt))
                        continue
                    error_msg = "No response"
                    break

                # Check for negative response
                if len(payload) >= 3 and payload[0] == 0x7F and payload[1] == 0x3E:
                    nrc = payload[2]
                    error_msg = f"NRC 0x{nrc:02X}"
                    if attempt < DEFAULT_RETRY_COUNT - 1 and _is_retryable_nrc(nrc):
                        _log(context, f"Retryable NRC {nrc:02X}, retrying", "WARN")
                        time.sleep(DEFAULT_RETRY_DELAY * (2 ** attempt))
                        continue
                    break

                # Positive response (7E 3E)
                active = bool(len(payload) >= 1 and payload[0] == 0x7E)
                break

            details[ecu_code] = active
            if not active and error_msg:
                errors[ecu_code] = error_msg
            
            # AR-PERSIST-002: Proper format for persistence (FIXED)
            ecu_statuses.append({
                "ecu_code": ecu_code,
                "is_active": active,
                "error_count": 0 if active else 1,
                "last_response": None,  # DB column is timestamp
                "error": error_msg if not active else None
            })

        ecus_ok = 1 if (details and all(details.values())) else 0
        _progress(100, "ECU Active Check completed")

        # Return in multiple formats for compatibility
        return {
            "ecus_ok": ecus_ok,
            "ecu_statuses": ecu_statuses,  # For service.py persistence
            "details": details,              # For backward compatibility
            "errors": errors,                 # Detailed errors for debugging
            "summary": f"{sum(details.values())}/{len(details)} ECUs active"
        }

    except Exception as e:
        _log(context, f"ECU check failed: {e}", "ERROR")
        return {
            "ecus_ok": 0,
            "ecu_statuses": [{
                "ecu_code": ecu,
                "is_active": False,
                "error_count": 1,
                "error": str(e)
            } for ecu in ecu_list],
            "details": {ecu: False for ecu in ecu_list},
            "errors": {ecu: str(e) for ecu in ecu_list}
        }
    finally:
        if bus:
            try:
                bus.shutdown()
                _log(context, "CAN bus closed")
            except Exception as e:
                _log(context, f"Error closing bus: {e}", "ERROR")


def _is_retryable_nrc(nrc: int) -> bool:
    """Check if a negative response code is retryable."""
    retryable_nrcs = {
        0x21,  # BRR - Busy Repeat Request
        0x25,  # NRFSC - No Response From Sub-net Component
        0x37,  # RTDNE - Required Time Delay Not Expired
        0x78,  # RCRRP - Response Pending
    }
    return nrc in retryable_nrcs